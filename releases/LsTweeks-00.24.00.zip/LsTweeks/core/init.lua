-- Addon entry point: initializes the shared addon table, defines shared constants,
-- sets up SavedVariables (Ls_Tweeks_DB), and registers the /lst slash command.
-- Loads first; every other file reads addon.UI_THEME and writes into Ls_Tweeks_DB through the patterns established here.


--#region FILE CONTENTS ======================================================


local addon_name, addon = ...
addon.name = addon_name
addon.module_defaults = {}
addon.SETTINGS_ICON_TEXTURE = "Interface\\Icons\\Trade_engineering"
addon.module_status_builders = {}
addon.alpha_affected_frames = {}

-- Shared UI font tokens used across all modules.
-- Rivet panel layout constants (padding, sizing, positioning) live in addon.RIVETED_PANEL_STYLE in panel_riveted.lua.
addon.UI_THEME = {
    font_title    = "GameFontHighlight",
    font_subtitle = "GameFontHighlightSmall",
    font_body     = "GameFontNormal",
}

-- Shared Aura Frames bar-color defaults.
addon.AURA_BAR_COLOR_DEFAULTS = {
    buff = { r = 0, g = 0.5, b = 1, a = 1 },
    debuff = { r = 1, g = 0.2, b = 0.2, a = 1 },
}

-- Shared by every fade control for new settings, missing-value fallback, and Reset.
addon.DEFAULT_FADE_ALPHA = 0.50

-- Shared timing buckets. Runtime code should choose a named bucket/profile
-- instead of scattering raw debounce or refresh intervals.
addon.UPDATE_INTERVALS = {
    next_frame = 0,
    tenth_sec = 0.1,
    fifth_sec = 0.2,
    half_sec = 0.5,
    six_tenths_sec = 0.6,
    one_point_two_sec = 1.2,
    two_point_five_sec = 2.5,
    five_sec = 5.0,
}

-- Behavior-specific timing aliases. Keep these as the adjustment points for
-- profiling and responsiveness tests instead of changing generic buckets.

-- CPU profile hotness: high; drives deferred Aura Frames refresh/update work.
addon.UPDATE_INTERVALS.aura_event_bucket = addon.UPDATE_INTERVALS.fifth_sec

-- CPU profile hotness: high; strongest direct ticker candidate from the profile.
addon.UPDATE_INTERVALS.aura_visible_icon_tick = addon.UPDATE_INTERVALS.tenth_sec

-- CPU profile hotness: low; hover-only maintenance path.
addon.UPDATE_INTERVALS.aura_hover_check = addon.UPDATE_INTERVALS.fifth_sec

-- CPU profile hotness: low; active only during Player Frame fade.
addon.UPDATE_INTERVALS.player_frame_fade_tick = addon.UPDATE_INTERVALS.tenth_sec
-- fifth_sec looks jittery

-- CPU profile hotness: low; coalesces noisy quest/achievement event bursts.
addon.UPDATE_INTERVALS.objectives_title_event_bucket = addon.UPDATE_INTERVALS.fifth_sec

-- CPU profile hotness: moderate; active only while a Skyriding Vigor node is filling.
addon.UPDATE_INTERVALS.skyriding_vigor_progress = 1 / 20

-- CPU profile hotness: bursty charge/cooldown events; keep display response prompt.
addon.UPDATE_INTERVALS.skyriding_vigor_event_bucket = addon.UPDATE_INTERVALS.tenth_sec

addon.FEATURE_MODULES = {
    { key = "chat_copy_sghetti", label = "ChatCopySghetti" },
    { key = "audio_volumes", label = "Audio Volumes" },
    { key = "aura_frames", label = "Buffs & Debuffs" },
    { key = "objectives", label = "Objectives" },
    { key = "player_frame", label = "Player Frame" },
    { key = "skyriding_vigor", label = "Skyriding Vigor" },
}

local function ensure_module_flags()
    if not Ls_Tweeks_DB then return end
    Ls_Tweeks_DB.modules = Ls_Tweeks_DB.modules or {}
    for _, module_def in ipairs(addon.FEATURE_MODULES) do
        if Ls_Tweeks_DB.modules[module_def.key] == nil then
            Ls_Tweeks_DB.modules[module_def.key] = true
        end
    end
end

function addon.is_module_enabled(module_key)
    if not module_key then return true end
    if not Ls_Tweeks_DB then return true end
    ensure_module_flags()
    return Ls_Tweeks_DB.modules[module_key] ~= false
end

function addon.set_module_enabled(module_key, enabled)
    if not module_key or not Ls_Tweeks_DB then return end
    ensure_module_flags()
    enabled = enabled ~= false
    if Ls_Tweeks_DB.modules[module_key] == enabled then return end
    Ls_Tweeks_DB.modules[module_key] = enabled

    addon[module_key].set_module_enabled(enabled)
    if addon.main_frame then
        addon.main_frame:RefreshSidebar()
    end
end

function addon.register_module_status(module_key, builder)
    if not module_key or type(builder) ~= "function" then return end
    addon.module_status_builders[module_key] = builder
end

local function append_status_fields(target, fields)
    if type(fields) == "table" then
        for _, field in ipairs(fields) do
            target[#target + 1] = tostring(field)
        end
    elseif fields ~= nil then
        target[#target + 1] = tostring(fields)
    else
        target[#target + 1] = "no runtime status registered"
    end
end

local function status_module_matches(module_def, filter)
    if not filter or filter == "" then return true end
    filter = filter:lower()
    local key = module_def and module_def.key and module_def.key:lower() or ""
    local label = module_def and module_def.label and module_def.label:lower() or ""
    return key == filter or label == filter
end

function addon.print_module_status(filter)
    ensure_module_flags()
    filter = (filter or ""):match("^%s*(.-)%s*$")
    local heading_suffix = filter ~= "" and (" (" .. filter .. ")") or ""
    print("|cff33ff99LsTweeks module status|r" .. heading_suffix)
    local printed = 0
    for _, module_def in ipairs(addon.FEATURE_MODULES) do
        if status_module_matches(module_def, filter) then
            local key = module_def.key
            local fields = { "enabled=" .. tostring(addon.is_module_enabled(key)) }
            local builder = addon.module_status_builders[key]
            if builder then
                local ok, result = pcall(builder)
                if ok then
                    append_status_fields(fields, result)
                else
                    fields[#fields + 1] = "status_error=" .. tostring(result)
                end
            else
                fields[#fields + 1] = "no runtime status registered"
            end
            local separator = filter ~= "" and "\n  " or ", "
            local module_status = (module_def.label or key) .. ": " .. table.concat(fields, separator)
            print(module_status)
            printed = printed + 1
        end
    end

    if printed == 0 then
        print("No module matched status filter: " .. tostring(filter))
    end
end


function addon.get_version()
    if not addon.version and C_AddOns and C_AddOns.GetAddOnMetadata then
        addon.version = C_AddOns.GetAddOnMetadata(addon_name, "Version")
    end
    return addon.version or "unknown"
end

-- DATABASE INITIALIZATION
local function init_db()
    -- Ensure the global DB exists with the Tweeks spelling
    _G.Ls_Tweeks_DB = _G.Ls_Tweeks_DB or {}

    -- Core Minimap defaults
    if not Ls_Tweeks_DB.minimap then
        Ls_Tweeks_DB.minimap = { hide = false }
    end

    -- Ensure the aura_frames sub-table exists for the module to use
    if not Ls_Tweeks_DB.aura_frames then
        Ls_Tweeks_DB.aura_frames = {}
    end
    ensure_module_flags()
end

-- MAIN INITIALIZATION SEQUENCE
local function on_event(self, _, name)
    if name ~= addon_name then return end

    -- Store version from TOC
    addon.get_version()

    -- Setup Global DB
    init_db()

    -- Initialize the core UI frame
    addon.init_main_frame()

    -- Initialize the LDB/Minimap button
    addon.init_minimap_button()

    -- Note: Aura Frames will initialize themselves in af_main.lua
    -- using the Ls_Tweeks_DB.aura_frames table we ensured exists above.
    self:UnregisterEvent("ADDON_LOADED")
    self:SetScript("OnEvent", nil)
end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent", on_event)

-- AUTO-OPEN on reload/login if the setting is enabled
local f2 = CreateFrame("Frame")
f2:RegisterEvent("PLAYER_ENTERING_WORLD")
f2:SetScript("OnEvent", function(self, _, isInitialLogin, isReloadingUi)
    if (isInitialLogin or isReloadingUi) and Ls_Tweeks_DB and Ls_Tweeks_DB.open_on_reload then
        if addon.main_frame then
            addon.main_frame:Show()
        end
    end
    self:UnregisterEvent("PLAYER_ENTERING_WORLD")
end)

-- SLASH COMMANDS
-- Primary command: /lst (short for L's Tweeks)
SLASH_LSTWEEKS1 = "/lst"
SlashCmdList["LSTWEEKS"] = function(msg)
    msg = (msg or ""):match("^%s*(.-)%s*$")
    local status_filter = msg:match("^[Ss][Tt][Aa][Tt][Uu][Ss]%s+(.+)$")
    if msg:lower() == "status" or status_filter then
        addon.print_module_status(status_filter)
        return
    end
    local tooltip_debug_action = msg:match("^[Tt][Oo][Oo][Ll][Tt][Ii][Pp][Dd][Ee][Bb][Uu][Gg]%s+(.+)$")
    if msg:lower() == "tooltipdebug" then
        if addon.PrintTooltipRendererHistory then
            addon.PrintTooltipRendererHistory()
        else
            print("|cff33ff99LsTweeks tooltip trace|r: tooltip helpers are unavailable")
        end
        return
    end
    if tooltip_debug_action then
        tooltip_debug_action = tooltip_debug_action:lower()
        if tooltip_debug_action == "mark" then
            if addon.MarkTooltipDebugTrace then
                addon.MarkTooltipDebugTrace()
                print("|cff33ff99LsTweeks tooltip trace|r: marker added; prior trace retained")
            else
                print("|cff33ff99LsTweeks tooltip trace|r: tooltip helpers are unavailable")
            end
            return
        end
        if tooltip_debug_action == "native-on" or tooltip_debug_action == "native-off" then
            if addon.SetNativeAuraTooltipTestEnabled then
                local enabled = tooltip_debug_action == "native-on"
                addon.SetNativeAuraTooltipTestEnabled(enabled)
                print(
                    "|cff33ff99LsTweeks tooltip trace|r: native Aura experiment "
                        .. (enabled and "enabled until reload" or "disabled")
                )
            else
                print("|cff33ff99LsTweeks tooltip trace|r: tooltip helpers are unavailable")
            end
            return
        end
    end
    if addon.main_frame then
        if addon.main_frame:IsShown() then
            addon.main_frame:Hide()
        else
            addon.main_frame:Show()
        end
    end
end

--#endregion FILE CONTENTS ===================================================
