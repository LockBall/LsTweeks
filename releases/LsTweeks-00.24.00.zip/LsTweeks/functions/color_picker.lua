-- Color picker widget that wraps the system ColorPickerFrame with an integrated reset button.
-- addon.CreateColorPicker(parent, db, key, has_alpha, label, defaults, cb, opts) returns a container;
-- the reset button restores the default color from the defaults table.
-- The callback reason is one of open/reset/swatch/alpha/cancel.
-- has_alpha is always forced true; every picker exposes opacity regardless of the argument passed.
-- Every picker also injects a row of preset swatches into the system ColorPickerFrame popup itself
-- (not a separate widget), using the palette below unless opts.presets / opts.color_presets override
-- the source. opts.on_select(value) overrides the default
-- apply-RGB-preserve-alpha behavior when a preset swatch is clicked; it must write db_table[db_key] itself.


local _, addon = ...

--#region COLOR PICKER CONSTANTS =============================================

-- Button / reset
local control_gap = 5
local CONTAINER_W  = 95
local CONTAINER_H  = 45
local BTN_SIZE     = 18
local RESET_W      = 45
local RESET_H      = 16
local GROUP_W      = BTN_SIZE + control_gap + RESET_W
local AUTO_VISIBLE_DEFAULT = 0.75
local PREVIEW_DEBOUNCE = addon.UPDATE_INTERVALS.tenth_sec
local DEFAULT_PRESET_OPTIONS = {
    { value = "red", text = "Red" },
    { value = "orange", text = "Orange" },
    { value = "yellow", text = "Yellow" },
    { value = "green", text = "Green" },
    { value = "blue", text = "Blue" },
    { value = "indigo", text = "Indigo" },
    { value = "violet", text = "Violet" },
    { value = "black", text = "Black" },
    { value = "white", text = "White" },
    { value = "grey", text = "Grey" },
}
local DEFAULT_COLOR_PRESETS = {
    red = { r = 1, g = 0, b = 0 },
    orange = { r = 1, g = 0.5, b = 0 },
    yellow = { r = 1, g = 1, b = 0 },
    green = { r = 0, g = 1, b = 0 },
    blue = { r = 0, g = 0, b = 1 },
    indigo = { r = 0.294, g = 0, b = 0.51 },
    violet = { r = 0.56, g = 0, b = 1 },
    black = { r = 0, g = 0, b = 0 },
    white = { r = 1, g = 1, b = 1 },
    grey = { r = 0.5, g = 0.5, b = 0.5 },
}

-- Popup
-- All X/Y values position the element's bottom-left corner from the popup's bottom-left corner.

-- Frame
local POPUP_WIDTH = 360
local POPUP_HEIGHT = 245

-- Alpha
local POPUP_ALPHA_FRAME_W = 90
local POPUP_ALPHA_FRAME_H = 36
local POPUP_ALPHA_BOX_W = 40
local POPUP_ALPHA_BOX_H = 16
local POPUP_ALPHA_TITLE_GAP = 4
local POPUP_ALPHA_X = 268
local POPUP_ALPHA_Y = 110

-- Hex
local POPUP_HEX_X = 245
local POPUP_HEX_Y = 48

-- Save / Cancel / Reset
local POPUP_BUTTON_W = 64
local POPUP_SAVE_X = 76
local POPUP_CANCEL_X = 148
local POPUP_RESET_X = 220
local POPUP_BUTTON_Y = 20

-- Preset row
local POPUP_PRESET_SWATCH_SIZE = 16
local POPUP_PRESET_SWATCH_GAP = 4
local POPUP_PRESET_ROW_X = 25
local POPUP_PRESET_ROW_Y = 50

--#endregion COLOR PICKER CONSTANTS ===========================================

--#region COLOR VALUE HELPERS =================================================

local function format_alpha_percent(a)
    if a == nil then a = 1 end
    return tostring(math.floor((a * 100) + 0.5))
end

local function color_alpha_or_default(a, default)
    if a == nil then return default end
    return a
end

-- Standard RGB->HSV conversion; ColorPickerFrame exposes GetColorRGB but no live RGB setter in the
-- 10.2.5+ picker, only the inner wheel widget's SetColorHSV. The native ColorSelect widget's
-- SetColorHSV/GetColorHSV take hue in degrees (0-360), not a 0-1 fraction.
local function rgb_to_hsv(r, g, b)
    local max_v, min_v = math.max(r, g, b), math.min(r, g, b)
    local delta = max_v - min_v
    local h = 0
    if delta > 0 then
        if max_v == r then
            h = ((g - b) / delta) % 6
        elseif max_v == g then
            h = ((b - r) / delta) + 2
        else
            h = ((r - g) / delta) + 4
        end
        h = h * 60
        if h < 0 then h = h + 360 end
    end
    local s = max_v > 0 and (delta / max_v) or 0
    return h, s, max_v
end

--#endregion COLOR VALUE HELPERS ==============================================

--#region POPUP FRAME HELPERS =================================================

local function get_popup_action_buttons()
    local footer = ColorPickerFrame and ColorPickerFrame["Footer"]
    local okay = (footer and footer["OkayButton"])
        or (ColorPickerFrame and ColorPickerFrame["OkayButton"])
        or _G["ColorPickerOkayButton"]
    local cancel = (footer and footer["CancelButton"])
        or (ColorPickerFrame and ColorPickerFrame["CancelButton"])
        or _G["ColorPickerCancelButton"]
    return okay, cancel
end

local function ensure_popup_reset_button()
    if ColorPickerFrame._lstweeks_reset_button then
        return ColorPickerFrame._lstweeks_reset_button
    end
    local reset = CreateFrame("Button", nil, ColorPickerFrame, "UIPanelButtonTemplate")
    reset:SetSize(POPUP_BUTTON_W, 22)
    reset:SetText("Reset")
    addon.ApplyStandardButtonStyle(reset)
    ColorPickerFrame._lstweeks_reset_button = reset
    return reset
end

local function capture_frame_layout(frame)
    if not (frame and frame.GetNumPoints and frame.GetPoint) then return nil end

    local layout = {
        width = frame:GetWidth(),
        height = frame:GetHeight(),
        points = {},
    }
    for index = 1, frame:GetNumPoints() do
        layout.points[index] = { frame:GetPoint(index) }
    end
    return layout
end

local function restore_frame_layout(frame, layout)
    if not (frame and layout) then return end

    frame:SetSize(layout.width, layout.height)
    frame:ClearAllPoints()
    for _, point in ipairs(layout.points) do
        frame:SetPoint(unpack(point))
    end
end

local function place_popup_action_buttons()
    local okay, cancel = get_popup_action_buttons()
    local reset = ensure_popup_reset_button()
    local candidates = { okay, cancel, reset }

    for _, button in ipairs(candidates) do
        if button and button.SetWidth then
            button:SetWidth(POPUP_BUTTON_W)
        end
    end

    if okay and cancel and okay.ClearAllPoints and cancel.ClearAllPoints then
        okay:ClearAllPoints()
        cancel:ClearAllPoints()
        reset:ClearAllPoints()
        okay:SetText("Save")
        okay:SetPoint("BOTTOMLEFT", ColorPickerFrame, "BOTTOMLEFT", POPUP_SAVE_X, POPUP_BUTTON_Y)
        cancel:SetPoint("BOTTOMLEFT", ColorPickerFrame, "BOTTOMLEFT", POPUP_CANCEL_X, POPUP_BUTTON_Y)
        reset:SetPoint("BOTTOMLEFT", ColorPickerFrame, "BOTTOMLEFT", POPUP_RESET_X, POPUP_BUTTON_Y)
        reset:Show()
    end
end

local function find_color_picker_hex_box()
    local function valid_edit_box(candidate)
        if candidate and candidate.GetObjectType and candidate:GetObjectType() == "EditBox" then
            return candidate
        end
        return nil
    end

    local content = ColorPickerFrame and ColorPickerFrame["Content"]
    return valid_edit_box(ColorPickerFrame and ColorPickerFrame["HexBox"])
        or valid_edit_box(content and content["HexBox"])
        or valid_edit_box(content and content["HexBoxEditBox"])
        or valid_edit_box(_G["ColorPickerFrameHexBox"])
end

local function place_color_picker_hex_box()
    local hex_box = find_color_picker_hex_box()
    if not hex_box then return end

    hex_box:ClearAllPoints()
    hex_box:SetPoint("BOTTOMLEFT", ColorPickerFrame, "BOTTOMLEFT", POPUP_HEX_X, POPUP_HEX_Y)
end

local function capture_native_popup_layout()
    local okay, cancel = get_popup_action_buttons()
    local hex_box = find_color_picker_hex_box()
    local content = ColorPickerFrame["Content"]
    ColorPickerFrame._lstweeks_native_layout = {
        popup_width = ColorPickerFrame:GetWidth(),
        popup_height = ColorPickerFrame:GetHeight(),
        content = { frame = content, layout = capture_frame_layout(content) },
        okay = { frame = okay, layout = capture_frame_layout(okay) },
        okay_text = okay and okay.GetText and okay:GetText(),
        cancel = { frame = cancel, layout = capture_frame_layout(cancel) },
        hex = { frame = hex_box, layout = capture_frame_layout(hex_box) },
    }
end

local function restore_native_popup_layout()
    local native_layout = ColorPickerFrame and ColorPickerFrame._lstweeks_native_layout
    if not native_layout then return end

    ColorPickerFrame:SetSize(native_layout.popup_width, native_layout.popup_height)
    restore_frame_layout(native_layout.content.frame, native_layout.content.layout)
    restore_frame_layout(native_layout.okay.frame, native_layout.okay.layout)
    restore_frame_layout(native_layout.cancel.frame, native_layout.cancel.layout)
    restore_frame_layout(native_layout.hex.frame, native_layout.hex.layout)
    if native_layout.okay.frame and native_layout.okay.frame.SetText then
        native_layout.okay.frame:SetText(native_layout.okay_text or "Okay")
    end
    local reset = ColorPickerFrame._lstweeks_reset_button
    if reset then
        reset:SetScript("OnClick", nil)
        reset:Hide()
    end
    ColorPickerFrame._lstweeks_native_layout = nil
end

local get_color_picker_alpha_slider

local function set_color_picker_alpha(alpha)
    local set_frame_alpha = ColorPickerFrame and ColorPickerFrame["SetColorAlpha"]
    if set_frame_alpha then
        set_frame_alpha(ColorPickerFrame, alpha)
        return
    end

    local content = ColorPickerFrame and ColorPickerFrame["Content"]
    local picker = content and content["ColorPicker"]
    local set_picker_alpha = picker and picker["SetColorAlpha"]
    if set_picker_alpha then
        set_picker_alpha(picker, alpha)
        return
    end

    local opacity_slider = get_color_picker_alpha_slider()
    if opacity_slider and opacity_slider.SetValue then
        opacity_slider:SetValue(alpha)
    end
end

get_color_picker_alpha_slider = function()
    local content = ColorPickerFrame and ColorPickerFrame["Content"]
    return ColorPickerFrame["OpacitySlider"]
        or (content and content["OpacitySlider"])
        or _G["ColorPickerFrameOpacitySlider"]
end

local function get_color_picker_widget()
    local content = ColorPickerFrame and ColorPickerFrame["Content"]
    return content and content["ColorPicker"]
end

local function clear_live_picker_callbacks(session)
    if not ColorPickerFrame then return end
    if session and ColorPickerFrame._lstweeks_live_session ~= session then return end

    ColorPickerFrame._lstweeks_live_session = nil
    ColorPickerFrame._lstweeks_live_swatch_func = nil
    ColorPickerFrame._lstweeks_live_opacity_func = nil
end

local cleanup_popup_layout

local function ensure_live_picker_session_cleanup()
    if not (ColorPickerFrame and ColorPickerFrame.HookScript) or ColorPickerFrame._lstweeks_live_session_hooked then return end

    ColorPickerFrame:HookScript("OnHide", function()
        clear_live_picker_callbacks()
        if cleanup_popup_layout then
            cleanup_popup_layout()
        end
    end)
    ColorPickerFrame._lstweeks_live_session_hooked = true
end

local hooked_color_pickers = setmetatable({}, { __mode = "k" })
local hooked_opacity_sliders = setmetatable({}, { __mode = "k" })

local function ensure_live_picker_hooks()
    local picker = get_color_picker_widget()
    if picker and picker.HookScript and not hooked_color_pickers[picker] then
        picker:HookScript("OnColorSelect", function()
            local handler = ColorPickerFrame and ColorPickerFrame._lstweeks_live_swatch_func
            if handler then
                handler()
            end
        end)
        hooked_color_pickers[picker] = true
    end

    local opacity_slider = get_color_picker_alpha_slider()
    if opacity_slider and opacity_slider.HookScript and not hooked_opacity_sliders[opacity_slider] then
        opacity_slider:HookScript("OnValueChanged", function()
            local handler = ColorPickerFrame and ColorPickerFrame._lstweeks_live_opacity_func
            if handler then
                handler()
            end
        end)
        hooked_opacity_sliders[opacity_slider] = true
    end
end

local function set_color_picker_value_midpoint()
    local picker = get_color_picker_widget()
    if picker and picker.GetColorHSV and picker.SetColorHSV then
        local h, s = picker:GetColorHSV()
        picker:SetColorHSV(h or 0, s or 0, AUTO_VISIBLE_DEFAULT)
        return true
    end

    return false
end

local function set_color_picker_rgb(r, g, b)
    local picker = get_color_picker_widget()
    if picker and picker.SetColorHSV then
        picker:SetColorHSV(rgb_to_hsv(r, g, b))
        return true
    end
    return false
end

--#endregion POPUP FRAME HELPERS ==============================================

--#region POPUP ALPHA INPUT ===================================================

local function ensure_popup_alpha_percent()
    if ColorPickerFrame._lstweeks_alpha_percent then
        return ColorPickerFrame._lstweeks_alpha_percent
    end

    local frame = CreateFrame("Frame", nil, ColorPickerFrame)
    frame:SetSize(POPUP_ALPHA_FRAME_W, POPUP_ALPHA_FRAME_H)
    frame:SetFrameLevel((ColorPickerFrame:GetFrameLevel() or 1) + 10)

    local label = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    label:SetText("Alpha %")

    local box = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
    box:SetSize(POPUP_ALPHA_BOX_W, POPUP_ALPHA_BOX_H)
    box:SetPoint("BOTTOM", frame, "BOTTOM", 0, 0)
    label:SetPoint("BOTTOM", box, "TOP", 0, POPUP_ALPHA_TITLE_GAP)
    box:SetAutoFocus(false)
    box:SetJustifyH("CENTER")
    box:SetTextInsets(-3, 0, 0, 0)

    frame.box = box
    ColorPickerFrame._lstweeks_alpha_percent = frame
    return frame
end

local function place_popup_alpha_percent(frame)
    frame:ClearAllPoints()
    frame:SetPoint("BOTTOMLEFT", ColorPickerFrame, "BOTTOMLEFT", POPUP_ALPHA_X, POPUP_ALPHA_Y)
end

local function hide_popup_alpha_percent()
    local frame = ColorPickerFrame and ColorPickerFrame._lstweeks_alpha_percent
    if frame then
        frame:Hide()
    end
end

local function set_popup_alpha_percent_text(alpha)
    local frame = ColorPickerFrame and ColorPickerFrame._lstweeks_alpha_percent
    if frame and frame.box then
        frame.box:SetText(format_alpha_percent(alpha))
    end
end

local function show_popup_alpha_percent(get_current, set_alpha)
    local frame = ensure_popup_alpha_percent()
    local box = frame.box

    place_popup_alpha_percent(frame)
    box:SetText(format_alpha_percent(get_current()))

    local function commit_alpha()
        local value = tonumber(box:GetText())
        if not value then
            box:SetText(format_alpha_percent(get_current()))
            box:ClearFocus()
            return
        end

        local alpha = math.max(0, math.min(100, value)) / 100
        set_color_picker_alpha(alpha)
        set_alpha(alpha)
        box:SetText(format_alpha_percent(alpha))
        box:ClearFocus()
    end

    box:SetScript("OnEnterPressed", commit_alpha)
    box:SetScript("OnEditFocusLost", commit_alpha)
    frame:Show()
end

--#endregion POPUP ALPHA INPUT ================================================

--#region POPUP PRESET SWATCHES ================================================

local function ensure_popup_presets(count)
    local frame = ColorPickerFrame._lstweeks_presets
    if frame and frame.swatches and #frame.swatches >= count then
        return frame
    end

    if not frame then
        frame = CreateFrame("Frame", nil, ColorPickerFrame)
        frame:SetFrameLevel((ColorPickerFrame:GetFrameLevel() or 1) + 10)
        frame.swatches = {}
        ColorPickerFrame._lstweeks_presets = frame
    end

    for index = #frame.swatches + 1, count do
        local swatch = CreateFrame("Button", nil, frame, "BackdropTemplate")
        swatch:SetSize(POPUP_PRESET_SWATCH_SIZE, POPUP_PRESET_SWATCH_SIZE)
        swatch:SetPoint("LEFT", frame, "LEFT", (index - 1) * (POPUP_PRESET_SWATCH_SIZE + POPUP_PRESET_SWATCH_GAP), 0)
        swatch:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            edgeSize = 6,
        })
        local highlight = swatch:CreateTexture(nil, "OVERLAY")
        highlight:SetAllPoints()
        highlight:SetColorTexture(1, 1, 1, 0.35)
        highlight:Hide()
        swatch:SetScript("OnEnter", function() highlight:Show() end)
        swatch:SetScript("OnLeave", function() highlight:Hide() end)
        frame.swatches[index] = swatch
    end

    return frame
end

local function place_popup_presets(frame, count)
    frame:SetSize(count * POPUP_PRESET_SWATCH_SIZE + math.max(0, count - 1) * POPUP_PRESET_SWATCH_GAP, POPUP_PRESET_SWATCH_SIZE)
    frame:ClearAllPoints()
    frame:SetPoint("BOTTOMLEFT", ColorPickerFrame, "BOTTOMLEFT", POPUP_PRESET_ROW_X, POPUP_PRESET_ROW_Y)
end

local function apply_custom_popup_size()
    local native_layout = ColorPickerFrame._lstweeks_native_layout
    local content = ColorPickerFrame["Content"]

    ColorPickerFrame:SetSize(POPUP_WIDTH, POPUP_HEIGHT)
    if content and native_layout then
        content:ClearAllPoints()
        content:SetPoint("TOPLEFT", ColorPickerFrame, "TOPLEFT")
        content:SetSize(native_layout.popup_width, native_layout.popup_height)
    end
end

local function hide_popup_presets()
    local frame = ColorPickerFrame and ColorPickerFrame._lstweeks_presets
    if frame then
        frame:Hide()
    end
end

local function show_popup_presets(presets, color_presets_lookup, on_pick)
    local frame = ensure_popup_presets(#presets)
    place_popup_presets(frame, #presets)

    for index, swatch in ipairs(frame.swatches) do
        local option = presets[index]
        if option then
            local preset = color_presets_lookup[option.value]
            if preset then
                swatch:SetBackdropColor(preset.r, preset.g, preset.b, 1)
            end
            addon.AttachTooltip(swatch, nil, option.text or tostring(option.value))
            swatch:SetScript("OnClick", function()
                on_pick(option.value)
            end)
            swatch:Show()
        else
            swatch:Hide()
        end
    end

    frame:Show()
end

cleanup_popup_layout = function()
    hide_popup_alpha_percent()
    hide_popup_presets()
    if ColorPickerFrame then
        restore_native_popup_layout()
    end
end

--#endregion POPUP PRESET SWATCHES =============================================

--#region COLOR PICKER FACTORY ===============================================

function addon.CreateColorPicker(parent, db_table, db_key, has_alpha, label_text, defaults_table, callback, opts)
    has_alpha = true
    opts = opts or {}
    local presets = opts.presets or DEFAULT_PRESET_OPTIONS
    local color_presets_lookup = opts.color_presets or DEFAULT_COLOR_PRESETS
    local has_presets = type(presets) == "table" and #presets > 0 and type(color_presets_lookup) == "table"
    local container = addon.CreateControlPanel(parent, CONTAINER_W, CONTAINER_H)

    -- Label
    local label = container:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    label:SetPoint("TOP", container, "TOP", 0, -control_gap)
    label:SetJustifyH("CENTER")
    label:SetText(label_text)

    -- Group centers button + reset as a unit below the label
    local group = CreateFrame("Frame", nil, container)
    group:SetSize(GROUP_W, BTN_SIZE)
    group:SetPoint("TOP", label, "BOTTOM", 0, -control_gap)

    -- Color Picker Button
    local button = CreateFrame("Button", nil, group, "BackdropTemplate")
    button:SetSize(BTN_SIZE, BTN_SIZE)
    button:SetPoint("LEFT", group, "LEFT", 0, 0)
    button:SetBackdrop({
        bgFile = "Interface\\ChatFrame\\ChatFrameColorSwatch",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 8
    })

    -- Reset Button
    local reset = CreateFrame("Button", nil, group, "UIPanelButtonTemplate")
    reset:SetSize(RESET_W, RESET_H)
    reset:SetText("Reset")
    addon.ApplyStandardButtonStyle(reset)
    reset:SetPoint("LEFT", button, "RIGHT", control_gap, 0)

    local preview_timer = nil
    local preview_reason = nil
    local function cancel_preview_timer()
        if preview_timer then
            preview_timer:Cancel()
            preview_timer = nil
        end
    end
    local function run_callback(reason)
        if type(callback) == "function" then callback(reason) end
    end
    local function queue_callback(reason)
        preview_reason = reason
        if preview_timer then return end
        if C_Timer and C_Timer.NewTimer then
            preview_timer = C_Timer.NewTimer(PREVIEW_DEBOUNCE, function()
                local queued_reason = preview_reason
                preview_timer = nil
                preview_reason = nil
                run_callback(queued_reason)
            end)
        else
            run_callback(reason)
        end
    end

    -- Local update helper
    local function apply_and_refresh(r, g, b, a, reason, immediate)
        button:SetBackdropColor(r, g, b, color_alpha_or_default(a, 1))
        if immediate then
            cancel_preview_timer()
            run_callback(reason)
        else
            queue_callback(reason)
        end
    end

    -- Setup Initial Color
    local c = db_table[db_key]
    if c then
        button:SetBackdropColor(c.r, c.g, c.b, color_alpha_or_default(c.a, 1))
    end

    -- Reset Logic with Type Check
    reset:SetScript("OnClick", function()
        -- Defensive check to ensure defaults_table is actually a table
        if type(defaults_table) ~= "table" then
            print("|cFFFF0000LsTweaks Error:|r Invalid defaults table in ColorPicker.")
            return
        end

        local dc = defaults_table[db_key]
        if dc then
            db_table[db_key] = has_alpha and {r=dc.r, g=dc.g, b=dc.b, a=dc.a} or {r=dc.r, g=dc.g, b=dc.b}
            apply_and_refresh(dc.r, dc.g, dc.b, dc.a, "reset", true)
        end
    end)

    -- Color Picker Dialog
    button:SetScript("OnClick", function()
        clear_live_picker_callbacks()
        if cleanup_popup_layout then
            cleanup_popup_layout()
        end
        local current = db_table[db_key]
        local session = {}
        if type(callback) == "function" then callback("open") end
        local auto_visible_from_transparent = has_alpha and current and (current.a or 0) == 0
        local auto_visible_done = false
        local auto_visible_applying = false
        local auto_visible_ready = false
        local function update_alpha(alpha, immediate)
            local r, g, b = ColorPickerFrame:GetColorRGB()
            db_table[db_key] = { r = r, g = g, b = b, a = alpha }
            apply_and_refresh(r, g, b, alpha, "alpha", immediate)
        end
        local function update_swatch()
            if auto_visible_applying then return end

            local r, g, b = ColorPickerFrame:GetColorRGB()
            local a = has_alpha and ColorPickerFrame:GetColorAlpha() or 1

            if auto_visible_from_transparent and auto_visible_ready and not auto_visible_done and not auto_visible_applying then
                auto_visible_done = true
                auto_visible_applying = true
                set_color_picker_alpha(AUTO_VISIBLE_DEFAULT)
                set_color_picker_value_midpoint()
                set_popup_alpha_percent_text(AUTO_VISIBLE_DEFAULT)
                r, g, b = ColorPickerFrame:GetColorRGB()
                a = AUTO_VISIBLE_DEFAULT
                auto_visible_applying = false
            end

            db_table[db_key] = has_alpha and {r=r, g=g, b=b, a=a} or {r=r, g=g, b=b}
            apply_and_refresh(r, g, b, a, "swatch", false)
            if has_alpha and ColorPickerFrame._lstweeks_alpha_percent and ColorPickerFrame._lstweeks_alpha_percent:IsShown() then
                ColorPickerFrame._lstweeks_alpha_percent.box:SetText(format_alpha_percent(a))
            end
        end
        local function update_opacity()
            local alpha = ColorPickerFrame:GetColorAlpha()
            update_alpha(alpha, false)
            set_popup_alpha_percent_text(alpha)
        end
        local function pick_preset(value)
            if opts.on_select then
                opts.on_select(value)
                local updated = db_table[db_key]
                if updated then
                    set_color_picker_rgb(updated.r, updated.g, updated.b)
                    if has_alpha then set_color_picker_alpha(color_alpha_or_default(updated.a, 1)) end
                    apply_and_refresh(updated.r, updated.g, updated.b, updated.a, "swatch", false)
                    set_popup_alpha_percent_text(color_alpha_or_default(updated.a, 1))
                end
                return
            end
            local preset = color_presets_lookup[value]
            if not preset then return end
            local alpha = has_alpha and ColorPickerFrame:GetColorAlpha() or 1
            set_color_picker_rgb(preset.r, preset.g, preset.b)
            db_table[db_key] = has_alpha and { r = preset.r, g = preset.g, b = preset.b, a = alpha }
                or { r = preset.r, g = preset.g, b = preset.b }
            apply_and_refresh(preset.r, preset.g, preset.b, alpha, "swatch", false)
        end

        ColorPickerFrame:SetupColorPickerAndShow({
            r = current.r, g = current.g, b = current.b,
            hasOpacity = has_alpha,
            opacity = color_alpha_or_default(current.a, 1),
            swatchFunc = update_swatch,
            opacityFunc = has_alpha and update_opacity or nil,
            cancelFunc = function()
                db_table[db_key] = current
                apply_and_refresh(current.r, current.g, current.b, current.a, "cancel", true)
                clear_live_picker_callbacks(session)
                cleanup_popup_layout()
            end
        })
        ColorPickerFrame._lstweeks_live_session = session
        ColorPickerFrame._lstweeks_live_swatch_func = update_swatch
        ColorPickerFrame._lstweeks_live_opacity_func = has_alpha and update_opacity or nil
        ensure_live_picker_session_cleanup()
        ensure_live_picker_hooks()
        capture_native_popup_layout()
        apply_custom_popup_size()
        place_popup_action_buttons()
        local popup_reset = ensure_popup_reset_button()
        popup_reset:SetScript("OnClick", function()
            local default = type(defaults_table) == "table" and defaults_table[db_key]
            if not default then return end
            local alpha = has_alpha and color_alpha_or_default(default.a, 1) or 1
            db_table[db_key] = has_alpha
                and { r = default.r, g = default.g, b = default.b, a = alpha }
                or { r = default.r, g = default.g, b = default.b }
            set_color_picker_rgb(default.r, default.g, default.b)
            if has_alpha then set_color_picker_alpha(alpha) end
            set_popup_alpha_percent_text(alpha)
            apply_and_refresh(default.r, default.g, default.b, alpha, "reset", true)
        end)
        place_color_picker_hex_box()
        if has_alpha then
            show_popup_alpha_percent(function()
                return color_alpha_or_default(db_table[db_key].a, 1)
            end, function(alpha)
                update_alpha(alpha, true)
            end)
        else
            hide_popup_alpha_percent()
        end
        if has_presets then
            show_popup_presets(presets, color_presets_lookup, pick_preset)
        else
            hide_popup_presets()
        end
        C_Timer.After(0, function()
            auto_visible_ready = true
        end)
    end)

    container.SetValue = function(_, color)
        if color then
            button:SetBackdropColor(color.r or 1, color.g or 1, color.b or 1, color_alpha_or_default(color.a, 1))
        end
    end

    container.GetValue = function()
        return db_table[db_key]
    end

    container.reset_button = reset

    container.SetEnabled = function(_, enabled)
        button:SetEnabled(enabled)
        reset:SetEnabled(enabled)
        button:SetAlpha(enabled and 1 or 0.45)
        reset:SetAlpha(enabled and 1 or 0.65)
        if label.SetFontObject then
            label:SetFontObject(enabled and GameFontNormalSmall or GameFontDisableSmall)
        end
    end

    return container
end

--#endregion COLOR PICKER FACTORY =============================================
