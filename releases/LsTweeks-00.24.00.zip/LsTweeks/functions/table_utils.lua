-- Shared table/default-copy utilities used across all modules.


local _, addon = ...

--#region TABLE COPYING ======================================================

function addon.deep_copy(value)
    if type(value) ~= "table" then return value end
    local result = {}
    for key, child in pairs(value) do
        result[key] = addon.deep_copy(child)
    end
    return result
end

-- Use after table.wipe(dest) to restore a DB table from defaults.
function addon.deep_copy_into(src, dest)
    for k, v in pairs(src) do
        if type(v) == "table" then
            dest[k] = {}
            addon.deep_copy_into(v, dest[k])
        else
            dest[k] = v
        end
    end
end

--#endregion TABLE COPYING ===================================================

--#region DEFAULT APPLICATION ================================================

-- Recursive fill-missing copy: only writes keys that are absent in dest.
-- Use to apply defaults onto an existing DB without overwriting user values.
function addon.apply_defaults(src, dest)
    for k, v in pairs(src) do
        if type(v) == "table" then
            dest[k] = dest[k] or {}
            addon.apply_defaults(v, dest[k])
        else
            if dest[k] == nil then dest[k] = v end
        end
    end
end

--#endregion DEFAULT APPLICATION =============================================

--#region NUMBER HELPERS ======================================================

function addon.clamp_number(value, fallback, range)
    value = tonumber(value)
    if not value then value = fallback end
    if range and value < range.min then return range.min end
    if range and value > range.max then return range.max end
    return value
end

--#endregion NUMBER HELPERS ===================================================
