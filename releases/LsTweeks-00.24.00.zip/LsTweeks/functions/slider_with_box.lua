-- Slider widget paired with a numeric text input and a reset button: addon.CreateSliderWithBox(name, parent, label, min, max, step, db, key, defaults, cb, opts).
-- Changes from either the slider or the box are synced to each other and written to the DB; callbacks debounce at addon.UPDATE_INTERVALS.tenth_sec unless opts.immediate_callback is set for live previews. Live callbacks apply the first value immediately, then throttle updates to addon.UPDATE_INTERVALS.tenth_sec while retaining the latest dragged value.
-- Programmatic refresh callers can use container:SetValueSilently(value) to sync display/DB without invoking the callback.
-- Use container:GetValue(), container:SetValue(value), and container:HookValueChanged(fn, opts)
-- instead of reaching into container.slider for routine value handling.


local _, addon = ...

--#region SLIDER CONSTANTS ====================================================

local UPDATE_INTERVALS = addon.UPDATE_INTERVALS
addon.SLIDER_WITH_BOX_SIZE = {
    width = 130,
    height = 95,
}
local SLIDER_WITH_BOX_SIZE = addon.SLIDER_WITH_BOX_SIZE

--#endregion SLIDER CONSTANTS =================================================

--#region SLIDER WITH BOX FACTORY ============================================

function addon.CreateSliderWithBox(name, parent, label_text, min_v, max_v, step, db_table, db_key, defaults_table, callback, opts)
    opts = opts or {}
    local container = addon.CreateControlPanel(parent, SLIDER_WITH_BOX_SIZE.width, SLIDER_WITH_BOX_SIZE.height)

    local control_gap = 5

    local eb_font_size = 12
    local eb_width = 35
    local eb_height = 12

    local reset_width = 42
    local reset_height = 20

    local slider_width = 120
    local button_size = 24
    local slider_inset = 3
    local step_button_font = "GameFontNormalLarge"
    local step_button_highlight_font = "GameFontHighlightLarge"
    local reset_button_font = "GameFontNormalSmall"
    local reset_button_highlight_font = "GameFontHighlightSmall"

    local function style_slider_button(button, normal_font, highlight_font)
        if not button then return end
        addon.ApplyStandardButtonStyle(button, {
            normal_font_object = normal_font,
            highlight_font_object = highlight_font or normal_font,
        })
    end

    local slider = CreateFrame("Slider", name, container, "MinimalSliderTemplate")
    slider:SetSize(slider_width, 16)
    slider:SetPoint("CENTER", container, "CENTER", 0, -control_gap/2)
    slider:SetMinMaxValues(min_v, max_v)
    slider:SetValueStep(step)
    slider:SetObeyStepOnDrag(true)
    slider:SetValue((db_table and db_table[db_key]) or min_v)

    local title = container:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    title:SetPoint("TOP", container, "TOP", 0, -control_gap)
    title:SetText(label_text)

    -- Min/Max labels
    local min_lbl = container:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    min_lbl:SetPoint("BOTTOMLEFT", slider, "TOPLEFT", slider_inset, control_gap)
    local function format_display_value(v)
        if opts.display_decimals then
            return format("%." .. opts.display_decimals .. "f", v)
        end
        if step >= 1 then
            return tostring(math.floor(v + 0.5))
        end
        if step >= 0.1 then
            return format("%.1f", v)
        end
        return format("%.2f", v)
    end

    min_lbl:SetText(format_display_value(min_v))

    local max_lbl = container:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    max_lbl:SetPoint("BOTTOMRIGHT", slider, "TOPRIGHT", -slider_inset, control_gap)
    max_lbl:SetText(format_display_value(max_v))

    -- Edit box
    local eb = CreateFrame("EditBox", nil, container, "InputBoxTemplate")
    eb:SetSize(eb_width, eb_height)
    eb:SetPoint("TOP", title, "BOTTOM", 0, -1.5*control_gap)
    eb:SetAutoFocus(false)
    eb:SetJustifyH("CENTER")
    eb:SetTextInsets(-4, 0, 0, 0)
    local font, _, flags = eb:GetFont()
    eb:SetFont(font, eb_font_size, flags)

    -- Minus and plus buttons under the slider, left and right
    local minus_btn = CreateFrame("Button", nil, container, "UIPanelButtonTemplate")
    minus_btn:SetSize(button_size, button_size)
    minus_btn:SetText("-")
    style_slider_button(minus_btn, step_button_font, step_button_highlight_font)
    minus_btn:SetPoint("TOPLEFT", slider, "BOTTOMLEFT", slider_inset, -control_gap)

    local plus_btn = CreateFrame("Button", nil, container, "UIPanelButtonTemplate")
    plus_btn:SetSize(button_size, button_size)
    plus_btn:SetText("+")
    style_slider_button(plus_btn, step_button_font, step_button_highlight_font)
    plus_btn:SetPoint("TOPRIGHT", slider, "BOTTOMRIGHT", -slider_inset, -control_gap)

    local reset = CreateFrame("Button", nil, container, "UIPanelButtonTemplate")
    reset:SetSize(reset_width, reset_height)
    reset:SetPoint("TOP", slider, "BOTTOM", 0, -control_gap)
    reset:SetText("Reset")
    style_slider_button(reset, reset_button_font, reset_button_highlight_font)


    eb:SetText(format_display_value((db_table and db_table[db_key]) or min_v))


    local function run_callback(value)
        if type(callback) == "function" then
            callback(value)
        end
    end

    local debounce_timer = nil
    local live_timer = nil
    local live_pending_value = nil
    local last_live_callback_at = nil
    local function cancel_debounce()
        if debounce_timer then
            debounce_timer:Cancel()
            debounce_timer = nil
        end
    end

    local function cancel_live_callback()
        if live_timer then
            live_timer:Cancel()
            live_timer = nil
        end
        live_pending_value = nil
    end

    local function debounced_callback(value)
        cancel_debounce()
        debounce_timer = C_Timer.NewTimer(UPDATE_INTERVALS.tenth_sec, function()
            debounce_timer = nil
            run_callback(value)
        end)
    end

    local function throttled_live_callback(value)
        local interval = opts.live_callback_interval or UPDATE_INTERVALS.tenth_sec
        local now = GetTime()
        local elapsed = last_live_callback_at and (now - last_live_callback_at) or interval
        if elapsed >= interval then
            cancel_live_callback()
            last_live_callback_at = now
            run_callback(value)
            return
        end

        live_pending_value = value
        if live_timer then return end
        live_timer = C_Timer.NewTimer(interval - elapsed, function()
            live_timer = nil
            local pending_value = live_pending_value
            live_pending_value = nil
            last_live_callback_at = GetTime()
            run_callback(pending_value)
        end)
    end

    container:SetScript("OnHide", function()
        cancel_debounce()
        cancel_live_callback()
    end)

    slider:SetScript("OnValueChanged", function(_, value)
        if db_table then
            db_table[db_key] = value
        end
        eb:SetText(format_display_value(value))
        if not container._suppress_callback and type(callback) == "function" then
            if opts.immediate_callback then
                cancel_debounce()
                throttled_live_callback(value)
            else
                debounced_callback(value)
            end
        end
    end)

    eb:SetScript("OnEnterPressed", function(self)
        local val = tonumber(self:GetText())
        if val then
            val = math.max(min_v, math.min(max_v, val))
            slider:SetValue(val)
        end
        self:ClearFocus()
    end)

    minus_btn:SetScript("OnClick", function()
        local v = slider:GetValue() - step
        slider:SetValue(math.max(min_v, v))
    end)

    plus_btn:SetScript("OnClick", function()
        local v = slider:GetValue() + step
        slider:SetValue(math.min(max_v, v))
    end)

    reset:SetScript("OnClick", function()
        local default_value = nil
        if type(opts.get_default_value) == "function" then
            default_value = opts.get_default_value(db_key)
        elseif defaults_table then
            -- Accept both table.key and table["key"] for Lua flexibility
            default_value = defaults_table[db_key]
        end
        if default_value == nil then
            default_value = min_v
        end
        if db_table then
            db_table[db_key] = default_value
        end
        eb:SetText(format_display_value(default_value))
        if slider:GetValue() ~= default_value then
            slider:SetValue(default_value)
        else
            run_callback(default_value)
        end
    end)

    if opts.tooltip then
        title:EnableMouse(true)
        addon.AttachTooltip(title, nil, opts.tooltip)
    end

    -- Expose the inner slider only for template-specific escape hatches.
    container.slider = slider
    container.GetValue = function()
        return slider:GetValue()
    end
    container.SetValue = function(_, value)
        if db_table then
            db_table[db_key] = value
        end
        eb:SetText(format_display_value(value))
        slider:SetValue(value)
    end
    container.SetValueSilently = function(_, value)
        cancel_debounce()
        cancel_live_callback()
        local was_suppressed = container._suppress_callback
        container._suppress_callback = true
        local ok, err = pcall(function()
            if db_table then
                db_table[db_key] = value
            end
            eb:SetText(format_display_value(value))
            slider:SetValue(value)
        end)
        container._suppress_callback = was_suppressed
        if not ok then error(err, 0) end
    end
    container.HookValueChanged = function(_, handler, hook_opts)
        if type(handler) ~= "function" then return end
        hook_opts = hook_opts or {}
        slider:HookScript("OnValueChanged", function(_, value)
            if container._suppress_callback and hook_opts.run_when_silent ~= true then
                return
            end
            handler(container, value)
        end)
    end
    container.SetEnabled = function(_, enabled)
        enabled = enabled and true or false
        slider:SetEnabled(enabled)
        eb:SetEnabled(enabled)
        minus_btn:SetEnabled(enabled)
        plus_btn:SetEnabled(enabled)
        reset:SetEnabled(enabled)
        container:SetAlpha(enabled and 1 or 0.45)
    end

    return container
end

--#endregion SLIDER WITH BOX FACTORY ==========================================
