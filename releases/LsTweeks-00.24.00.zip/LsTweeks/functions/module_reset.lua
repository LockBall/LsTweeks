-- ARM-code safety reset button: addon.CreateModuleReset(parent, db, defaults, opts).
-- The user must type "arm" into an input box before the reset button activates, preventing accidental wipes.
-- Blocked entirely during combat via InCombatLockdown(). Optional opts.before_reset
-- lets callers refresh dynamic defaults immediately before the copy, or cancel
-- the reset by returning false. Optional
-- opts.after_reset lets a module resync only its own runtime/controls.


local _, addon = ...

--#region MODULE RESET FACTORY ================================================

function addon.CreateModuleReset(parent, db, defaults, opts)
    opts = opts or {}

    -------- CONFIGURATION VARIABLES --------
    local DIM_ALPHA     = 0.5   -- Faded transparency when the button is locked
    local READY_ALPHA   = 0.6   -- Full transparency when 'arm' is typed

    -- PULSE Params
    local PULSE_MIN     = 0.0   -- Minimum brightness during the pulse cycle
    local PULSE_MAX     = 1.1   -- Maximum brightness during the pulse cycle
    local PULSE_SPEED   = 0.75  -- Duration in seconds for one pulse cycle

    -- MASK SETTINGS
    local MASK_INSET    = 13    -- Circular window size adjustment

    -- GLOW SIZE PARAMETERS
    local GLOW_SIZE     = 60
    local BEZEL_SPILL   = 7

    -- LAYOUT: Panel
    local PANEL_MIN_WIDTH   = 300   -- Minimum panel width (px)
    local PANEL_HEIGHT      = 150   -- Panel height (px)
    local PANEL_H_PADDING   = 100   -- Left+right padding around the control group
    local TITLE_Y           = -20   -- Title offset from panel top

    -- LAYOUT: Group
    local GROUP_X           = 0     -- Horizontal offset of the control group from panel center
    local GROUP_Y           = -45   -- Vertical offset of the control group from panel top
    local GROUP_PAD_X       = 6     -- Horizontal inner padding inside the control group
    local GROUP_PAD_TOP     = 4     -- Top inner padding inside the control group
    local GROUP_PAD_BOTTOM  = 4     -- Bottom inner padding inside the control group

    -- LAYOUT: Group Elements
    local INPUT_W           = 75    -- Width of the ARM code input box
    local INPUT_H           = 20    -- Height of the ARM code input box
    local LABEL_GAP         = 10    -- Gap between input top and label bottom
    local OPTION_GAP        = 10    -- Gap between input bottom and optional preserve checkbox
    local BTN_GAP           = 44    -- Gap between input right edge and button left edge
    local BTN_SIZE          = 64    -- Width and height of the icon button
    local RIVET_INSET       = 14    -- Distance of each rivet from panel corners
    local RIVET_OFFSET_X    = 0     -- Horizontal shift for all rivets (px)
    local RIVET_OFFSET_Y    = 0     -- Vertical shift for all rivets (px)
    -----------------------------------------

    -- CONTAINER
    -- No default positioning — caller is responsible for SetPoint after creation.
    local container = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    container:SetSize(PANEL_MIN_WIDTH, PANEL_HEIGHT)
    container:SetFrameLevel(parent:GetFrameLevel() + 10)

    addon.ApplyRivetedPanelStyle(container, {
        bgFile = "Interface\\FrameGeneral\\UI-Background-Rock",
        edgeSize = 30,
        rivetInset = RIVET_INSET,
        rivetOffsetX = RIVET_OFFSET_X,
        rivetOffsetY = RIVET_OFFSET_Y,
    })

    -- TITLE
    local title = container:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", container, "TOP", 0, TITLE_Y)
    title:SetText("Hal's Module Reset")
    title:SetTextColor(1, 0.82, 0)

    local control_row_width = INPUT_W + BTN_GAP + BTN_SIZE

    -- Control group: keeps input, label, and button aligned as one movable unit.
    local controlGroup = CreateFrame("Frame", nil, container)
    controlGroup:SetSize(1, 1)
    controlGroup:SetPoint("TOP", container, "TOP", GROUP_X, GROUP_Y)

    -- INPUT BOX
    local eb = CreateFrame("EditBox", nil, controlGroup, "InputBoxTemplate")
    eb:SetSize(INPUT_W, INPUT_H)
    eb:SetAutoFocus(false)
    eb:SetTextInsets(0, 7, 0, 0)
    eb:SetJustifyH("CENTER")
    eb:SetFontObject("NumberFontNormal")
    eb:SetTextColor(1, 1, 1)

    -- INSTRUCTION LABEL
    local label = controlGroup:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetText(" Input 'arm' code !?")

    local label_w = math.ceil(label:GetStringWidth() or 0)
    local label_h = math.ceil(label:GetStringHeight() or 0)
    local content_w = math.max(control_row_width, label_w)
    local top_extent = math.max(BTN_SIZE / 2, INPUT_H / 2 + LABEL_GAP + label_h)
    local bottom_extent = math.max(BTN_SIZE / 2, INPUT_H / 2)
    if opts.preserve_label then
        bottom_extent = math.max(bottom_extent, INPUT_H / 2 + OPTION_GAP + 20)
    end
    local content_h = top_extent + bottom_extent
    local group_w = content_w + GROUP_PAD_X * 2
    local group_h = content_h + GROUP_PAD_TOP + GROUP_PAD_BOTTOM

    controlGroup:SetSize(group_w, group_h)

    -- BIG RED BUTTON ICON
    local btn = CreateFrame("Button", nil, controlGroup)
    btn:SetSize(BTN_SIZE, BTN_SIZE)
    btn:SetPoint("CENTER", controlGroup, "CENTER", GROUP_PAD_X + content_w / 2 - BTN_SIZE / 2, 0)
    btn:Disable()

    eb:SetPoint("RIGHT", btn, "LEFT", -BTN_GAP, 0)
    label:SetPoint("BOTTOM", eb, "TOP", 0, LABEL_GAP)

    local preserve_container
    if opts.preserve_label then
        preserve_container = addon.CreateCheckbox(controlGroup, opts.preserve_label, opts.preserve_default == true)
        preserve_container:SetPoint("TOP", eb, "BOTTOM", 0, -OPTION_GAP)
    end

    -- STATIC BUTTON TEXTURE
    local bgTex = btn:CreateTexture(nil, "BACKGROUND")
    bgTex:SetAllPoints()
    bgTex:SetTexture("Interface\\Icons\\inv_misc_enggizmos_27")
    bgTex:SetAlpha(DIM_ALPHA)

    -- PULSING OVERLAY
    local pulseTex = btn:CreateTexture(nil, "ARTWORK")
    pulseTex:SetSize(GLOW_SIZE + BEZEL_SPILL, GLOW_SIZE + BEZEL_SPILL)
    pulseTex:SetPoint("CENTER")
    pulseTex:SetTexture("Interface\\Icons\\inv_misc_enggizmos_27")
    pulseTex:SetBlendMode("ADD")
    pulseTex:SetAlpha(0)

    -- CIRCULAR MASK
    local mask = btn:CreateMaskTexture()
    mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    mask:SetPoint("TOPLEFT",     pulseTex, "TOPLEFT",     MASK_INSET, -MASK_INSET)
    mask:SetPoint("BOTTOMRIGHT", pulseTex, "BOTTOMRIGHT", -MASK_INSET, MASK_INSET)
    pulseTex:AddMaskTexture(mask)

    -- CIRCULAR BORDER
    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Artifacts\\ArtifactRelic-Slot")
    border:SetDesaturated(true)
    border:SetAllPoints()
    border:SetAlpha(0.2)

    -- PUSHED TEXTURE
    btn:SetPushedTexture("Interface\\Buttons\\UI-Quickslot-Depress")
    btn:GetPushedTexture():SetBlendMode("MOD")

    -- Size the panel to its content instead of stretching to the tab width.
    local panel_width = math.max(
        PANEL_MIN_WIDTH,
        math.ceil((title:GetStringWidth() or 0) + 56),
        math.ceil((label:GetStringWidth() or 0) + 56),
        math.ceil(controlGroup:GetWidth() + PANEL_H_PADDING)
    )
    container:SetWidth(panel_width)

    -- PULSE ANIMATION
    local ag = pulseTex:CreateAnimationGroup()
    local animAlpha = ag:CreateAnimation("Alpha")
    animAlpha:SetFromAlpha(PULSE_MIN)
    animAlpha:SetToAlpha(PULSE_MAX)
    animAlpha:SetDuration(PULSE_SPEED)
    animAlpha:SetSmoothing("IN_OUT")
    ag:SetLooping("BOUNCE")

    local function disarm()
        eb:SetText("")
        eb:ClearFocus()
        btn:Disable()
        ag:Stop()
        bgTex:SetAlpha(DIM_ALPHA)
        pulseTex:SetAlpha(0)
        eb:SetFontObject("NumberFontNormal")
        eb:SetTextColor(1, 1, 1)
    end

    -- SECURITY LOGIC: AUTO-CLEAR
    container:SetScript("OnHide", function()
        disarm()
    end)

    -- INTERACTIVE SCRIPTS
    btn:SetScript("OnEnter", function(self)
        if self:IsEnabled() then ag:Play() end
    end)

    btn:SetScript("OnLeave", function(self)
        ag:Stop()
        pulseTex:SetAlpha(self:IsEnabled() and READY_ALPHA or 0)
    end)

    -- TERMINAL INPUT LOGIC
    eb:SetScript("OnTextChanged", function(self)
        local raw = self:GetText()
        local upper = raw:upper()
        if raw ~= upper then self:SetText(upper) end

        if upper == "ARM" then
            btn:Enable()
            bgTex:SetAlpha(READY_ALPHA)
            pulseTex:SetAlpha(READY_ALPHA)
            self:ClearFocus()
            self:SetFontObject("NumberFont_Shadow_Med")
            self:SetTextColor(0, 1, 0)
        else
            btn:Disable()
            ag:Stop()
            bgTex:SetAlpha(DIM_ALPHA)
            pulseTex:SetAlpha(0)
            self:SetFontObject("NumberFontNormal")
            self:SetTextColor(1, 1, 1)
        end
    end)

    -- RESET EXECUTION
    btn:SetScript("OnClick", function()
        if container._disabled then return end
        if InCombatLockdown() then
            print("|cffff4444LsTweaks:|r Cannot reset during combat.")
            return
        end

        PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)

        local preserved = {}
        local preserve_checked = preserve_container and preserve_container.GetChecked and preserve_container:GetChecked()
        if preserve_checked and opts.preserve_keys then
            for _, key in ipairs(opts.preserve_keys) do
                if db[key] ~= nil then
                    preserved[key] = {}
                    addon.deep_copy_into({ value = db[key] }, preserved[key])
                end
            end
        end

        if opts.before_reset and opts.before_reset() == false then
            disarm()
            return
        end

        -- Wipe and restore this module's DB from its defaults.
        table.wipe(db)
        addon.deep_copy_into(defaults, db)

        for key, wrapper in pairs(preserved) do
            db[key] = wrapper.value
        end
        if (not preserve_checked) and opts.preserve_keys then
            for _, key in ipairs(opts.preserve_keys) do
                db[key] = nil
            end
        end

        if opts.after_reset then
            opts.after_reset()
        end

        disarm()
        print("|cff00ff00LsTweaks:|r Module reset complete and synchronized.")
    end)

    container.SetEnabled = function(_, enabled)
        container._disabled = not enabled
        eb:SetEnabled(enabled)
        if not enabled then
            disarm()
        end
    end

    return container
end

--#endregion MODULE RESET FACTORY =============================================
