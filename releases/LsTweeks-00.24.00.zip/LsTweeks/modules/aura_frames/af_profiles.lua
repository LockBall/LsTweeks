-- Aura Frames profile schema and runtime application.
-- Shared profile storage and CRUD live in functions/profiles.lua.

local _, addon = ...

--#region PROFILE SCHEMA =======================================================

local M = addon.aura_frames

local PROFILE_GLOBAL_KEYS = {
    "enable_blizz_buffs", "enable_blizz_debuffs", "short_threshold", "aura_visible_icon_tick",
    "shared_options_enabled", "shared_test_auras", "disable_ooc_fade",
}
for _, column in ipairs(M.SHARED_COLOR_COLUMNS) do
    for _, picker in ipairs(column.pickers) do
        PROFILE_GLOBAL_KEYS[#PROFILE_GLOBAL_KEYS + 1] = picker.db_key
    end
end
for _, text_def in ipairs(M.TEXT_OPTION_DEFS) do
    PROFILE_GLOBAL_KEYS[#PROFILE_GLOBAL_KEYS + 1] = text_def.shared_prefix .. "_color"
    PROFILE_GLOBAL_KEYS[#PROFILE_GLOBAL_KEYS + 1] = text_def.shared_font_key
    PROFILE_GLOBAL_KEYS[#PROFILE_GLOBAL_KEYS + 1] = text_def.shared_prefix .. "_font_size"
    PROFILE_GLOBAL_KEYS[#PROFILE_GLOBAL_KEYS + 1] = text_def.shared_prefix .. "_font_bold"
    PROFILE_GLOBAL_KEYS[#PROFILE_GLOBAL_KEYS + 1] = text_def.shared_prefix .. "_font_outline"
end
local PROFILE_CATEGORY_PREFIXES = M.PRESENTATION_PROFILE_CATEGORY_PREFIXES
local CUSTOM_PROFILE_KEYS = {
    "id", "name", "aura_base_filter", "aura_modifier", "position",
}
for _, key in ipairs(M.CUSTOM_PRESENTATION_PROFILE_KEYS) do
    CUSTOM_PROFILE_KEYS[#CUSTOM_PROFILE_KEYS + 1] = key
end

local copy = addon.deep_copy
local function copy_keys(source, dest, keys)
    for _, key in ipairs(keys) do
        if source[key] ~= nil then dest[key] = copy(source[key]) end
    end
end
local function apply_keys(source, dest, keys)
    for _, key in ipairs(keys) do
        if source[key] ~= nil then
            dest[key] = copy(source[key])
        else
            dest[key] = nil
        end
    end
end

local function should_profile_category_prefix(category, prefix)
    return prefix ~= "test_aura" or M.frame_supports_test_aura(category)
end

function M.export_aura_frame_profile_data()
    if not M.db then return nil end
    local data = {}
    copy_keys(M.db, data, PROFILE_GLOBAL_KEYS)
    for _, category in ipairs(M.CATEGORIES) do
        for _, prefix in ipairs(PROFILE_CATEGORY_PREFIXES) do
            if should_profile_category_prefix(category, prefix) then
                local key = prefix .. "_" .. category
                if M.db[key] ~= nil then data[key] = copy(M.db[key]) end
            end
        end
    end
    data.positions = copy(M.db.positions or {})
    data.custom_frames = {}
    for _, entry in ipairs(M.db.custom_frames or {}) do
        local entry_copy = {}
        copy_keys(entry, entry_copy, CUSTOM_PROFILE_KEYS)
        data.custom_frames[#data.custom_frames + 1] = entry_copy
    end
    return data
end

function M.apply_aura_frame_profile_data(data)
    if not (M.db and data) then return false, "Profile data is missing." end
    addon.CloseFontOptionsPopup(false)
    apply_keys(data, M.db, PROFILE_GLOBAL_KEYS)
    for _, category in ipairs(M.CATEGORIES) do
        for _, prefix in ipairs(PROFILE_CATEGORY_PREFIXES) do
            if should_profile_category_prefix(category, prefix) then
                local key = prefix .. "_" .. category
                if data[key] ~= nil then
                    M.db[key] = copy(data[key])
                elseif M.defaults[key] ~= nil then
                    M.db[key] = copy(M.defaults[key])
                else
                    M.db[key] = nil
                end
            end
        end
    end
    M.db.positions = copy(data.positions or {})
    M.db.custom_frames = copy(data.custom_frames or {})
    addon.apply_defaults(M.defaults, M.db)
    M.normalize_saved_colors(M.db)
    for _, entry in ipairs(M.db.custom_frames) do
            local show_key = entry.id and ("show_" .. entry.id)
            if show_key and not M.frames[show_key] then M.create_custom_frame(entry) end
        end
    M.on_reset_complete()
    return true, "Loaded profile."
end

M.profile_manager = addon.CreateProfileManager({
    label = "Aura Frames",
    get_db = function() return M.db end,
    export_data = M.export_aura_frame_profile_data,
    apply_data = M.apply_aura_frame_profile_data,
})

--#endregion PROFILE SCHEMA ====================================================
