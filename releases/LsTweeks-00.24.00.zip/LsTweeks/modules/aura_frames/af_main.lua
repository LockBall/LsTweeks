-- Bootstrap and frame construction for the aura frames module
-- loads last so all other af_* files have already populated M.
-- Creates preset and custom aura frames with addon-owned icon pools or managed backends,
-- buckets UNIT_AURA events, starts the timer ticker, and registers the settings tab.

local addon_name, addon = ...
local M = addon.aura_frames

--#region MODULE STATE AND COOLDOWN REFRESH ====================================
-- Runtime state tables. The saved DB is attached during ADDON_LOADED.
-- CACHED GLOBALS AND CONSTANTS
local format = string.format
local floor = math.floor
local math_max = math.max
local GetTime = GetTime
local issecretvalue = issecretvalue
local WOW_COOLDOWN_CATEGORIES = M.CDM_CATEGORIES
local UPDATE_INTERVALS = addon.UPDATE_INTERVALS

local WOW_COOLDOWN_REFRESH_PROFILES = {
    immediate = {
        delays = { UPDATE_INTERVALS.next_frame },
    },
    hook = {
        delays = { UPDATE_INTERVALS.next_frame },
        defer_zero = true,
    },
    combat_entry = {
        delays = {
            UPDATE_INTERVALS.tenth_sec,
            UPDATE_INTERVALS.fifth_sec,
            UPDATE_INTERVALS.six_tenths_sec,
        },
        mark_scan_dirty = true,
    },
    startup = {
        delays = {
            UPDATE_INTERVALS.fifth_sec,
            UPDATE_INTERVALS.six_tenths_sec,
            UPDATE_INTERVALS.one_point_two_sec,
            UPDATE_INTERVALS.two_point_five_sec,
            UPDATE_INTERVALS.five_sec,
        },
    },
    settings = {
        delays = {
            UPDATE_INTERVALS.next_frame,
            UPDATE_INTERVALS.fifth_sec,
            UPDATE_INTERVALS.six_tenths_sec,
            UPDATE_INTERVALS.one_point_two_sec,
        },
    },
}

local function remove_runtime_frame_from_list(frame)
    local frames_list = M.frames_list
    if not (frames_list and frame) then return end
    for i = #frames_list, 1, -1 do
        if frames_list[i] == frame then
            table.remove(frames_list, i)
        end
    end
end

local function register_runtime_frame(show_key, frame)
    local old_frame = M.frames[show_key]
    if old_frame and old_frame ~= frame then
        remove_runtime_frame_from_list(old_frame)
    end
    remove_runtime_frame_from_list(frame)
    M.frames[show_key] = frame
    M.frames_list[#M.frames_list + 1] = frame
end

local function unregister_runtime_frame(show_key)
    local frame = M.frames[show_key]
    if frame then
        remove_runtime_frame_from_list(frame)
    end
    M.frames[show_key] = nil
    return frame
end

local function apply_text_style(font_target, category, cfg_db, text_type, alpha)
    if not font_target or not font_target.SetFont then return end
    local text_def = M.TEXT_OPTION_DEFS_BY_TYPE[text_type]
    if not text_def then return end
    local selected_key = M.get_setting(
        cfg_db,
        category,
        text_def.local_prefix .. "_font",
        M.DEFAULT_AURA_FONT_KEY
    )
    local size = M.get_text_font_size(category, cfg_db, text_type)
    local use_outline = M.get_setting(
        cfg_db,
        category,
        text_def.local_prefix .. "_font_outline",
        text_def.default_outline
    ) == true
    local bold = M.get_setting(cfg_db, category, text_def.local_prefix .. "_font_bold", false) == true
    local color = M.get_setting(cfg_db, category, text_def.color_key)
    local options = M.resolve_text_options(category, text_type, {
            color = color,
            font = selected_key,
            size = size,
            bold = bold,
            outline = use_outline,
        })
        color = options.color
        selected_key = options.font
        size = options.size
        bold = options.bold == true
        use_outline = options.outline ~= false
    addon.ApplySelectedFont(font_target, {
        key = selected_key,
        role = text_def.role,
        size = size,
        bold = bold,
        outline = use_outline,
        min_size = 6,
        max_size = text_def.max_size,
    })

    if cfg_db or M.db then
        if color then
            font_target:SetTextColor(
                color.r or 1,
                color.g or 1,
                color.b or 1,
                alpha == nil and (color.a or 1) or alpha
            )
        end
    end
end


function M.apply_number_font_style(font_target, category, cfg_db, alpha)
    apply_text_style(font_target, category, cfg_db, "timer", alpha)
end

function M.apply_stack_font_style(font_target, category, cfg_db, alpha)
    apply_text_style(font_target, category, cfg_db, "stack", alpha)
end

function M.apply_bar_text_style(font_target, category, cfg_db)
    apply_text_style(font_target, category, cfg_db, "bar")
end

function M.apply_number_font_to_text(font_string, category, cfg_db)
    M.apply_number_font_style(font_string, category, cfg_db)
end

function M.apply_number_font_to_all()
    local frames_list = M.frames_list
    if not frames_list then return end
    for i = 1, #frames_list do
        local frame = frames_list[i]
        if frame and frame.icons then
            local category = frame.category
            local cfg_db = frame._cfg_db
            for _, obj in ipairs(frame.icons) do
                if obj and obj.time_text then
                    M.apply_number_font_to_text(obj.time_text, category, cfg_db)
                end
                if obj and obj.count_text then
                    M.apply_stack_font_style(obj.count_text, category, cfg_db)
                end
                if obj and obj.name_text then
                    M.apply_bar_text_style(obj.name_text, category, cfg_db)
                end
            end
        end
        local backend = frame and frame._managed_aura_backend
        if backend then
            local category = frame.category
            local cfg_db = frame._cfg_db
            if backend.duration_font then
                M.apply_number_font_style(backend.duration_font, category, cfg_db)
            end
            if backend.stack_font then
                M.apply_stack_font_style(backend.stack_font, category, cfg_db)
            end
            if backend.bar_font then
                M.apply_bar_text_style(backend.bar_font, category, cfg_db)
            end
            for _, font_string in pairs(backend.bar_text_regions or {}) do
                M.apply_bar_text_style(font_string, category, cfg_db)
            end
        end
    end
end

local function run_wow_cooldown_refresh(refresh_config, category_filter)
    if not M.is_runtime_enabled() then return end

    if refresh_config.mark_scan_dirty then
        M.invalidate_aura_scan_caches()
    end

    M.update_all_blizz_cdm_visibility()

    for _, category in ipairs(WOW_COOLDOWN_CATEGORIES) do
        if not category_filter or category == category_filter then
            local show_key = M.get_preset_keys(category).show_key
            local frame = M.frames[show_key]
            local p = frame and frame.update_params
            if p and frame:IsShown() then
                M.update_auras(frame, p.show_key, p.move_key, p.timer_key, p.bg_key, p.scale_key, p.spacing_key, p.aura_filter)
            end
        end
    end
end

local function schedule_wow_cooldown_refresh(delay, refresh_config, category_filter)
    delay = delay or 0
    local key = tostring(delay)
        .. "|" .. tostring(refresh_config.defer_zero == true)
        .. "|" .. tostring(refresh_config.mark_scan_dirty == true)
        .. "|" .. tostring(category_filter or "")
    if M._cdm_refresh_pending[key] then return end

    local function refresh()
        M._cdm_refresh_pending[key] = nil
        run_wow_cooldown_refresh(refresh_config, category_filter)
    end

    M._cdm_refresh_pending[key] = true
    if (delay > 0 or refresh_config.defer_zero) and C_Timer and C_Timer.After then
        C_Timer.After(delay, refresh)
    else
        refresh()
    end
end

function M.queue_wow_cooldown_refresh(profile, category_filter)
    local refresh_config = type(profile) == "table" and profile
        or WOW_COOLDOWN_REFRESH_PROFILES[profile or "immediate"]
        or WOW_COOLDOWN_REFRESH_PROFILES.immediate
    if category_filter and not M.WOW_COOLDOWN_CATEGORIES[category_filter] then
        category_filter = nil
    end
    local delays = refresh_config.delays or { refresh_config.delay or 0 }
    for _, delay in ipairs(delays) do
        schedule_wow_cooldown_refresh(delay, refresh_config, category_filter)
    end
end

function M.install_cdm_layout_refresh_hook()
    if M._cdm_layout_refresh_hooked then return true end
    local cdm_api = C_CooldownViewer
    if not (cdm_api and type(cdm_api.SetLayoutData) == "function" and hooksecurefunc) then
        return false
    end

    hooksecurefunc(cdm_api, "SetLayoutData", function()
        if not M.is_runtime_enabled() then return end
        M.queue_wow_cooldown_refresh("settings")
    end)
    M._cdm_layout_refresh_hooked = true
    return true
end

--#endregion MODULE STATE AND COOLDOWN REFRESH =================================
--#region AURA ICON TOOLTIPS ===================================================

local function hide_aura_tooltip(owner)
    addon.HideNativeTooltip(owner)
    addon.HideOwnedTooltip()
end

local function is_usable_tooltip_number(value)
    return type(value) == "number" and not (issecretvalue and issecretvalue(value))
end

local function is_usable_tooltip_text(value)
    return type(value) == "string" and not (issecretvalue and issecretvalue(value))
end

local function get_aura_tooltip_cache_keys_for_identity(aura_instance_id, spell_id)
    local aura_key
    if is_usable_tooltip_number(aura_instance_id) then
        aura_key = "aura:" .. tostring(aura_instance_id)
    end
    local spell_key
    if is_usable_tooltip_number(spell_id) then
        spell_key = "spell:" .. tostring(spell_id)
    end
    return aura_key, spell_key
end

local function has_cacheable_tooltip_identity(obj)
    return is_usable_tooltip_number(obj.aura_index) or is_usable_tooltip_number(obj.aura_spell_id)
end

local function get_safe_basic_aura_name(obj)
    if is_usable_tooltip_text(obj.aura_name) then
        return obj.aura_name
    end
    if is_usable_tooltip_number(obj.aura_spell_id) then
        return "Aura " .. tostring(obj.aura_spell_id)
    end
    return "Aura"
end

function M.format_aura_tooltip_duration(seconds)
    seconds = math_max(0, floor(seconds or 0))
    local days = floor(seconds / 86400)
    seconds = seconds % 86400
    local hours = floor(seconds / 3600)
    seconds = seconds % 3600
    local minutes = floor(seconds / 60)
    local secs = seconds % 60
    if days > 0 then
        return format("%dd %02dh %02dm %02ds", days, hours, minutes, secs)
    end
    return format("%02dh %02dm %02ds", hours, minutes, secs)
end

local function get_safe_basic_aura_remaining(obj)
    if is_usable_tooltip_number(obj.aura_expiration) then
        return math_max(0, obj.aura_expiration - GetTime())
    end
    if is_usable_tooltip_number(obj.aura_remaining) then
        return obj.aura_remaining
    end
    return nil
end

local function get_safe_tooltip_data_for_identity(aura_instance_id, spell_id)
    if not C_TooltipInfo then return nil end

    if is_usable_tooltip_number(aura_instance_id) and C_TooltipInfo.GetUnitAuraByAuraInstanceID then
        local ok, data = pcall(C_TooltipInfo.GetUnitAuraByAuraInstanceID, "player", aura_instance_id)
        if ok and data then
            return data
        end
    end

    if is_usable_tooltip_number(spell_id) and C_TooltipInfo.GetSpellByID then
        local ok, data = pcall(C_TooltipInfo.GetSpellByID, spell_id)
        if ok and data then
            return data
        end
    end
end

local function cache_tooltip_data_lines_for_identity(aura_instance_id, spell_id)
    local aura_key, spell_key = get_aura_tooltip_cache_keys_for_identity(aura_instance_id, spell_id)
    if not aura_key and not spell_key then return nil end
    local aura_cached = aura_key and M._tooltip_data_lines_cache[aura_key]
    local spell_cached = spell_key and M._tooltip_data_lines_cache[spell_key]
    local cached = aura_cached or spell_cached
    if cached then
        if aura_key then M._tooltip_data_lines_cache[aura_key] = cached end
        if spell_key then M._tooltip_data_lines_cache[spell_key] = cached end
        return cached
    end

    if InCombatLockdown and InCombatLockdown() then
        return nil
    end

    local lines = addon.CopySafeTooltipDataLines(
        get_safe_tooltip_data_for_identity(aura_instance_id, spell_id)
    )
    if lines then
        if aura_key then M._tooltip_data_lines_cache[aura_key] = lines end
        if spell_key then M._tooltip_data_lines_cache[spell_key] = lines end
    end
    return lines
end

local function cache_tooltip_data_lines(obj)
    return cache_tooltip_data_lines_for_identity(obj.aura_index, obj.aura_spell_id)
end

function M.clear_aura_tooltip_instance_cache()
    local cache = M._tooltip_data_lines_cache
    if cache then
        for key in pairs(cache) do
            if type(key) == "string" and key:sub(1, 5) == "aura:" then
                cache[key] = nil
            end
        end
    end
end

function M.prewarm_aura_tooltip_cache(frame)
    if not M.is_runtime_enabled() then return end
    if InCombatLockdown and InCombatLockdown() then return end
    local icons = frame and frame.icons
    if not icons then return end

    local display_count = frame._display_count or 0
    if display_count > #icons then
        display_count = #icons
    end

    local missed = false
    for i = 1, display_count do
        local obj = icons[i]
        if obj
            and obj.tooltip_enabled ~= false
            and not obj.is_test_preview
            and has_cacheable_tooltip_identity(obj)
        then
            if not cache_tooltip_data_lines(obj) then
                missed = true
            end
        end
    end

    if not missed then
        frame._tooltip_cache_retry_count = 0
        return
    end
    if frame._tooltip_cache_retry_pending then return end
    if (frame._tooltip_cache_retry_count or 0) >= 2 then return end

    frame._tooltip_cache_retry_count = (frame._tooltip_cache_retry_count or 0) + 1
    frame._tooltip_cache_retry_pending = true
    local retry_frame = frame
    C_Timer.After(UPDATE_INTERVALS.fifth_sec, function()
        retry_frame._tooltip_cache_retry_pending = false
        if not (InCombatLockdown and InCombatLockdown()) then
            M.prewarm_aura_tooltip_cache(retry_frame)
        end
    end)
end

local function build_basic_aura_tooltip_lines(obj)
    local lines = {
        {
            left_text = get_safe_basic_aura_name(obj),
            left_color = { r = 1, g = 1, b = 1 },
        },
    }
    local remaining = get_safe_basic_aura_remaining(obj)
    local has_total_duration = is_usable_tooltip_number(obj.aura_duration) and obj.aura_duration > 0
    local has_remaining_time = is_usable_tooltip_number(remaining)
    if has_total_duration or has_remaining_time then
        local remaining_str = is_usable_tooltip_number(remaining)
            and M.format_aura_tooltip_duration(remaining)
            or "?"
        lines[#lines + 1] = {
            left_text = "Remaining: " .. remaining_str,
            left_color = { r = 0.7, g = 0.7, b = 1 },
        }
        if has_total_duration then
            lines[#lines + 1] = {
                left_text = "Duration: " .. M.format_aura_tooltip_duration(obj.aura_duration),
                left_color = { r = 0.7, g = 0.7, b = 1 },
            }
        end
    else
        lines[#lines + 1] = {
            left_text = "(Permanent)",
            left_color = { r = 0.7, g = 0.7, b = 1 },
        }
    end
    return lines
end

local function show_aura_icon_tooltip(obj)
    if obj.tooltip_enabled == false then
        hide_aura_tooltip(obj)
        return
    end

    if is_usable_tooltip_number(obj.aura_index)
        and addon.ShowNativeAuraTooltip(obj, "player", obj.aura_index, "ANCHOR_BOTTOMRIGHT")
    then
        return
    end

    local known_lines = cache_tooltip_data_lines(obj)
    local lines = known_lines or build_basic_aura_tooltip_lines(obj)
    addon.ShowOwnedTooltipLines(obj, lines, "ANCHOR_BOTTOMRIGHT")
end

local function aura_frame_contains_mouse(frame)
    if not frame then return false end
    for _, edge in ipairs(frame.move_handle and frame.move_handle.hit_areas or {}) do
        if edge.IsMouseOver and edge:IsMouseOver() then return true end
    end
    if frame.resizer and frame.resizer.IsMouseOver and frame.resizer:IsMouseOver() then return true end

    local icons = frame.icons
    if icons then
        local display_count = frame._display_count or #icons
        if display_count > #icons then display_count = #icons end
        for i = 1, display_count do
            local icon = icons[i]
            if icon and icon:IsShown() and icon.IsMouseOver and icon:IsMouseOver() then
                return true
            end
        end
    end
    return false
end

local function stop_frame_hover_check(frame)
    if frame and frame._hover_check_ticker then
        frame._hover_check_ticker:Cancel()
        frame._hover_check_ticker = nil
    end
end

local function frame_uses_ooc_fade(frame)
    if not frame then return false end
    local params = frame.update_params
    local cfg_db = M.get_frame_config_db(frame)
    if not (params and cfg_db) then return false end

    local activity = M.get_frame_activity_state(frame, params.show_key, params.move_key)
    if not activity.enabled or activity.moving then return false end
    return M.get_setting(cfg_db, frame.category, "fade_ooc", false) == true
end

local function set_frame_hovered(frame, hovered)
    if hovered and not frame_uses_ooc_fade(frame) then return false end
    M.set_aura_frame_hovered(frame, hovered)
    if not hovered then
        stop_frame_hover_check(frame)
    end
    return true
end

local function handle_frame_mouse_enter(frame)
    if not set_frame_hovered(frame, true) then return end
    if frame and not frame._hover_check_ticker and C_Timer and C_Timer.NewTicker then
        frame._hover_check_ticker = C_Timer.NewTicker(addon.UPDATE_INTERVALS.aura_hover_check, function()
            if not aura_frame_contains_mouse(frame) then
                set_frame_hovered(frame, false)
            end
        end)
    end
end

local function handle_frame_mouse_leave(frame)
    if not frame then return end
    C_Timer.After(0, function()
        if not aura_frame_contains_mouse(frame) then
            set_frame_hovered(frame, false)
        end
    end)
end

--#endregion AURA ICON TOOLTIPS ================================================

--#region AURA ICON POOL =======================================================

-- The icon pool is a fixed set of reusable icon/bar frame objects owned by one
-- aura frame. It is created up front because WoW combat lockdown makes runtime
-- frame creation unsafe; render code updates and shows/hides these pooled objects.
local function create_icon_cooldown(obj)
    local cooldown = CreateFrame("Cooldown", nil, obj, "CooldownFrameTemplate")
    cooldown:SetAllPoints(obj)
    cooldown:SetDrawEdge(false)
    cooldown:SetDrawSwipe(true)
    cooldown:SetDrawBling(false)
    cooldown:SetSwipeColor(0, 0, 0, 0.7)
    cooldown:SetHideCountdownNumbers(false)
    cooldown:Hide()
    return cooldown
end

local function create_icon_bar(obj, bar_bg_default)
    local bar = CreateFrame("StatusBar", nil, obj)
    bar:EnableMouse(false)
    bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    bar:SetMinMaxValues(0, 1)
    bar:Hide()

    obj.bar_bg = bar:CreateTexture(nil, "BACKGROUND")
    obj.bar_bg:SetAllPoints()
    obj.bar_bg:SetColorTexture(
        bar_bg_default.r,
        bar_bg_default.g,
        bar_bg_default.b,
        bar_bg_default.a or M.BAR_BG_ALPHA_DEFAULT
    )

    return bar
end

local function create_icon_text_regions(obj, category, cfg_db)
    -- Text overlay is created after the bar so labels render above bar fills.
    obj.text_overlay = CreateFrame("Frame", nil, obj)
    obj.text_overlay:EnableMouse(false)
    obj.text_overlay:SetFrameLevel(obj.bar:GetFrameLevel() + 1)

    obj.stack_slot = CreateFrame("Frame", nil, obj.text_overlay)
    M.add_debug_outline(obj.stack_slot, 1, 0.4, 0, 0.9)

    obj.name_slot = CreateFrame("Frame", nil, obj.text_overlay)
    M.add_debug_outline(obj.name_slot, 0, 0.6, 1, 0.9)

    obj.name_text = obj.text_overlay:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    M.apply_bar_text_style(obj.name_text, category, cfg_db)
    obj.name_text:SetJustifyH("LEFT")
    obj.name_text:SetWordWrap(false)
    if obj.name_text.SetMaxLines then
        obj.name_text:SetMaxLines(1)
    end

    obj.timer_slot = CreateFrame("Frame", nil, obj.text_overlay)
    M.add_debug_outline(obj.timer_slot, 0, 1, 0.3, 0.9)

    obj.time_text = obj.text_overlay:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    M.apply_number_font_to_text(obj.time_text, category, cfg_db)
    obj.time_text:SetWordWrap(false)
    if obj.time_text.SetMaxLines then
        obj.time_text:SetMaxLines(1)
    end

    obj.count_text = obj.text_overlay:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
    M.apply_stack_font_style(obj.count_text, category, cfg_db)
    obj.count_text:Hide()
end

local function bind_icon_tooltip(obj)
    obj:EnableMouse(true)
    obj:SetScript("OnEnter", function(self)
        handle_frame_mouse_enter(self:GetParent())
        show_aura_icon_tooltip(self)
    end)
    obj:SetScript("OnLeave", function(self)
        hide_aura_tooltip(self)
        handle_frame_mouse_leave(self:GetParent())
    end)
    obj:SetScript("OnMouseUp", function(self, button)
        M.try_cancel_aura_icon(self, button)
    end)
end

local function create_aura_icon(parent, category, cfg_db, bar_bg_default)
    local obj = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    obj:Hide()

    obj.texture = obj:CreateTexture(nil, "ARTWORK")
    obj.cooldown = create_icon_cooldown(obj)
    obj.bar = create_icon_bar(obj, bar_bg_default)
    create_icon_text_regions(obj, category, cfg_db)
    bind_icon_tooltip(obj)

    return obj
end

local function create_aura_icon_pool(frame, cfg_db, category, pool_size)
    frame.icons = {}
    pool_size = pool_size or M.AURA_FRAME_LIMIT
    local bar_bg_default = M.get_bar_bg_color(cfg_db, category)

    for i = 1, pool_size do
        frame.icons[i] = create_aura_icon(frame, category, cfg_db, bar_bg_default)
    end
end

--#endregion AURA ICON POOL ====================================================

--#region AURA FRAME SHELL =====================================================

-- The frame shell is the user-facing container around an aura icon pool. It owns
-- the drag handle, resize handle, saved width updates, and resize refresh so
-- icon creation/rendering can stay separate from frame interaction behavior.
local MOVE_BORDER_HIT_WIDTH = 8
local MANAGED_MOVE_HIT_WIDTH = 12
local MANAGED_MOVE_HIT_OUTSET = 4
local RESIZE_HANDLE_SIZE = 16
local RESIZE_HANDLE_BACKGROUND = { r = 0.03, g = 0.03, b = 0.03, a = 0.95 }
local RESIZE_GRIP_MARK_SIZE = 3

local function set_move_border_edge_points(edge, parent, side)
    if side == "TOP" then
        edge:SetPoint("TOPLEFT", parent, "TOPLEFT")
        edge:SetPoint("TOPRIGHT", parent, "TOPRIGHT")
        edge:SetHeight(MOVE_BORDER_HIT_WIDTH)
    elseif side == "BOTTOM" then
        edge:SetPoint("BOTTOMLEFT", parent, "BOTTOMLEFT")
        edge:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", -RESIZE_HANDLE_SIZE, 0)
        edge:SetHeight(MOVE_BORDER_HIT_WIDTH)
    elseif side == "LEFT" then
        edge:SetPoint("TOPLEFT", parent, "TOPLEFT")
        edge:SetPoint("BOTTOMLEFT", parent, "BOTTOMLEFT")
        edge:SetWidth(MOVE_BORDER_HIT_WIDTH)
    else
        edge:SetPoint("TOPRIGHT", parent, "TOPRIGHT")
        edge:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", 0, RESIZE_HANDLE_SIZE)
        edge:SetWidth(MOVE_BORDER_HIT_WIDTH)
    end
end

local function create_aura_frame_move_handle(parent, label, scale_key)
    local tb = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    tb:SetAllPoints(parent)
    tb:SetFrameLevel(parent:GetFrameLevel() + 10)
    tb.title = label
    M.apply_thin_border_backdrop(tb, nil, M.MOVE_BORDER_COLOR)

    tb.hit_areas = {}
    for _, side in ipairs({ "TOP", "BOTTOM", "LEFT", "RIGHT" }) do
        local edge = CreateFrame("Frame", nil, tb)
        set_move_border_edge_points(edge, tb, side)
        edge:EnableMouse(true)
        edge:RegisterForDrag("LeftButton")
        edge:SetScript("OnEnter", function(self)
            handle_frame_mouse_enter(parent)
            addon.ShowOwnedTooltip(self, tb.title, tb.body, "ANCHOR_RIGHT")
        end)
        edge:SetScript("OnLeave", function()
            addon.HideOwnedTooltip()
            handle_frame_mouse_leave(parent)
        end)
        edge:SetScript("OnDragStart", function()
            addon.HideOwnedTooltip()
            M.start_frame_drag(parent)
        end)
        edge:SetScript("OnDragStop", function()
            M.stop_frame_drag(parent, scale_key)
            if tb._lstweeks_sync_xy_sliders then
                tb._lstweeks_sync_xy_sliders()
            end
        end)
        tb.hit_areas[#tb.hit_areas + 1] = edge
    end

    return tb
end

local function position_aura_frame_move_handle(frame)
    local handle = frame and frame.move_handle
    if not handle then return end

    local managed_mover_edge = frame._managed_mover_edge
    local uses_safe_mover_edge = frame._managed_aura_backend or frame._managed_cdm_backend
    if frame._managed_cdm_backend and not managed_mover_edge then
        managed_mover_edge = "TOP"
    end

    local cdm_backend = frame._managed_cdm_backend
    local cdm_aura_mode = cdm_backend
        and cdm_backend.cfg_db["cooldown_mode_" .. cdm_backend.category] ~= true
    if frame._managed_aura_backend or cdm_aura_mode then
        handle:SetBackdropBorderColor(0, 0, 0, 0)
    else
        local color = M.MOVE_BORDER_COLOR
        handle:SetBackdropBorderColor(color.r, color.g, color.b, color.a)
    end
    if uses_safe_mover_edge then
        local mover_side = managed_mover_edge == "BOTTOM" and 2 or 1
        for index, edge in ipairs(handle.hit_areas or {}) do
            edge:SetShown(index == mover_side)
        end
        local mover_edge = handle.hit_areas and handle.hit_areas[mover_side]
        if mover_edge then
            mover_edge:ClearAllPoints()
            mover_edge:SetPoint(managed_mover_edge .. "LEFT", handle,
                managed_mover_edge .. "LEFT", 0,
                managed_mover_edge == "BOTTOM" and -MANAGED_MOVE_HIT_OUTSET
                    or MANAGED_MOVE_HIT_OUTSET)
            mover_edge:SetPoint(managed_mover_edge .. "RIGHT", handle,
                managed_mover_edge .. "RIGHT", -RESIZE_HANDLE_SIZE,
                managed_mover_edge == "BOTTOM" and -MANAGED_MOVE_HIT_OUTSET
                    or MANAGED_MOVE_HIT_OUTSET)
            mover_edge:SetHeight(MANAGED_MOVE_HIT_WIDTH)
        end
    end

    if frame.resizer then
        frame.resizer:ClearAllPoints()
        local point = "BOTTOMRIGHT"
        if frame._managed_aura_backend and frame._managed_mover_edge ~= "BOTTOM" then
            point = "TOPRIGHT"
        end
        frame.resizer:SetPoint(point, frame, point, 0, 0)
        frame.resizer:SetFrameLevel(handle:GetFrameLevel() + 1)
        for index, mark in ipairs(frame.resizer.grip_marks or {}) do
            local offset = 2 + ((index - 1) * 4)
            mark:ClearAllPoints()
            mark:SetPoint(point, frame.resizer, point, -offset,
                point == "TOPRIGHT" and -offset or offset)
        end
    end
end

function M.update_aura_frame_move_controls(frame, shown)
    if not frame then return end
    if shown then
        position_aura_frame_move_handle(frame)
    end
    M.set_shown_if_changed(frame.move_handle, shown)
    M.set_shown_if_changed(frame.resizer, shown)
end

local function save_aura_frame_width(frame, category, width)
    if frame.is_custom and frame.custom_entry then
        frame.custom_entry.width = width
    elseif M.db then
        M.db["width_"..category] = width
    end
end

local function get_width_slider_control(frame, category)
    if frame.is_custom and frame.custom_entry and frame.custom_entry.id then
        return M.controls["custom_" .. frame.custom_entry.id .. "_width"]
    end
    return M.controls["width_slider_"..category]
end

local function refresh_aura_frame_after_resize(frame)
    local params = frame.update_params
    if not params then return end
    M.invalidate_frame_runtime_config(frame)
    M.update_auras(frame, params.show_key, params.move_key, params.timer_key,
        params.bg_key, params.scale_key, params.spacing_key, params.aura_filter)
end

local function clamp_aura_frame_width(frame)
    local width = frame:GetWidth()
    if width < M.MIN_FRAME_WIDTH then
        width = M.MIN_FRAME_WIDTH
        frame:SetWidth(width)
    end
    return width
end

local function create_aura_frame_resizer(frame, category)
    frame.resizer = CreateFrame("Button", nil, frame, "BackdropTemplate")
    frame.resizer:EnableMouse(true)
    frame.resizer:SetSize(RESIZE_HANDLE_SIZE, RESIZE_HANDLE_SIZE)
    frame.resizer:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 0)
    M.apply_thin_border_backdrop(frame.resizer, RESIZE_HANDLE_BACKGROUND, M.MOVE_BORDER_COLOR)
    frame.resizer.grip_marks = {}
    for index = 1, 3 do
        local mark = frame.resizer:CreateTexture(nil, "OVERLAY")
        local color = M.MOVE_BORDER_COLOR
        local offset = 2 + ((index - 1) * 4)
        mark:SetColorTexture(color.r, color.g, color.b, color.a)
        mark:SetSize(RESIZE_GRIP_MARK_SIZE, RESIZE_GRIP_MARK_SIZE)
        mark:SetPoint("BOTTOMRIGHT", frame.resizer, "BOTTOMRIGHT", -offset, offset)
        frame.resizer.grip_marks[index] = mark
    end
    frame.resizer:SetScript("OnEnter", function()
        handle_frame_mouse_enter(frame)
    end)
    frame.resizer:SetScript("OnLeave", function()
        handle_frame_mouse_leave(frame)
    end)

    frame:SetScript("OnSizeChanged", function(s, w)
        if s._clamping_size then return end
        if w and w < M.MIN_FRAME_WIDTH then
            s._clamping_size = true
            s:SetWidth(M.MIN_FRAME_WIDTH)
            s._clamping_size = nil
            w = M.MIN_FRAME_WIDTH
        end
        if w then
            M.update_managed_move_outline_width(s, w)
        end
    end)

    frame.resizer:SetScript("OnMouseDown", function()
        frame._is_user_positioning = true
        frame:StartSizing("RIGHT")
    end)
    frame.resizer:SetScript("OnMouseUp", function()
        frame:StopMovingOrSizing()
        frame._is_user_positioning = nil

        local clamped_width = clamp_aura_frame_width(frame)
        save_aura_frame_width(frame, category, clamped_width)

        local width_slider = get_width_slider_control(frame, category)
        if width_slider then
            width_slider:SetValueSilently(clamped_width)
        end

        refresh_aura_frame_after_resize(frame)
    end)
end

--#endregion AURA FRAME SHELL ==================================================

--#region AURA FRAME EVENTS ====================================================

local function create_aura_frame_update_params(show_key, move_key, timer_key, bg_key, scale_key, spacing_key, category, aura_filter)
    return {
        show_key = show_key,
        move_key = move_key,
        timer_key = timer_key,
        bg_key = bg_key,
        scale_key = scale_key,
        spacing_key = spacing_key,
        category = category,
        aura_filter = aura_filter,
    }
end

local function register_combat_state_events(frame)
    frame:RegisterEvent("PLAYER_REGEN_DISABLED")
    frame:RegisterEvent("PLAYER_REGEN_ENABLED")
end

local function register_aura_frame_events(frame, category)
    frame:RegisterUnitEvent("UNIT_AURA", "player")
    frame:RegisterEvent("PLAYER_ENTERING_WORLD")
    register_combat_state_events(frame)
    frame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")

    if M.WOW_COOLDOWN_CATEGORIES[category] then
        frame:RegisterEvent("SPELL_UPDATE_COOLDOWN")
        frame:RegisterEvent("SPELL_UPDATE_CHARGES")
        frame:RegisterEvent("COOLDOWN_VIEWER_DATA_LOADED")
        frame:RegisterEvent("COOLDOWN_VIEWER_TABLE_HOTFIXED")
        frame:RegisterEvent("COOLDOWN_VIEWER_SPELL_OVERRIDE_UPDATED")
    end
end

local function is_aura_frame_event_relevant(event, unit)
    return (event == "UNIT_AURA" and unit == "player")
        or event == "PLAYER_ENTERING_WORLD"
        or event == "PLAYER_REGEN_DISABLED"
        or event == "PLAYER_REGEN_ENABLED"
        or event == "PLAYER_SPECIALIZATION_CHANGED"
        or event == "SPELL_UPDATE_COOLDOWN"
        or event == "SPELL_UPDATE_CHARGES"
        or event == "COOLDOWN_VIEWER_DATA_LOADED"
        or event == "COOLDOWN_VIEWER_TABLE_HOTFIXED"
        or event == "COOLDOWN_VIEWER_SPELL_OVERRIDE_UPDATED"
end

local function queue_deferred_aura_scan(frame, params)
    if frame._scan_pending then return end

    frame._scan_pending = true
    local f = frame
    -- A short bucket matches ElkBuffBars' short UNIT_AURA bucket and coalesces
    -- noisy event bursts while ensuring scans run outside event-dispatch taint.
    C_Timer.After(UPDATE_INTERVALS.aura_event_bucket, function()
        f._scan_pending = false
        M.update_auras(f, params.show_key, params.move_key, params.timer_key,
            params.bg_key, params.scale_key, params.spacing_key, params.aura_filter)
    end)
end

local function handle_aura_frame_event(frame, event, unit)
    local params = frame.update_params
    if not params then return end
    if not is_aura_frame_event_relevant(event, unit) then return end

    if event == "PLAYER_ENTERING_WORLD" then
        M.clear_aura_tooltip_instance_cache()
    end

    local activity = M.get_frame_activity_state(frame, params.show_key, params.move_key)
    if not M.should_process_aura_frame_event(activity, event) then
        return
    end

    if event == "PLAYER_REGEN_DISABLED" then
        M.prewarm_aura_tooltip_cache(frame)
    end

    -- Do not scan inside the event handler. C_UnitAuras calls made directly
    -- during event dispatch can return secret values in combat, so every frame
    -- update is deferred through the short aura bucket below.
    if event ~= "SPELL_UPDATE_COOLDOWN" and event ~= "SPELL_UPDATE_CHARGES" then
        M.invalidate_aura_scan_caches()
    end
    if event == "PLAYER_REGEN_DISABLED"
        and M.WOW_COOLDOWN_CATEGORIES[params.category] then
        M.queue_wow_cooldown_refresh("combat_entry")
    end

    queue_deferred_aura_scan(frame, params)
end

local function handle_managed_aura_shell_event(frame, event)
    M.refresh_frame_fade_for_combat_state(frame, event == "PLAYER_REGEN_DISABLED")
end

local function bind_managed_aura_shell_events(frame)
    frame:UnregisterAllEvents()
    register_combat_state_events(frame)
    frame:SetScript("OnEvent", handle_managed_aura_shell_event)
end

local function bind_aura_frame_events(frame, category)
    if frame._managed_aura_backend then
        bind_managed_aura_shell_events(frame)
        return
    end
    register_aura_frame_events(frame, category)
    frame:SetScript("OnEvent", handle_aura_frame_event)
end

-- AURA CONTAINER GENERATOR
function M.create_aura_frame(show_key, move_key, timer_key, bg_key, scale_key, spacing_key, display_name, is_debuff, frame_opts)
    local category = show_key:sub(6)
    frame_opts = frame_opts or {}
    local frame = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    frame.category = category
    frame.is_custom = frame_opts.is_custom == true
    frame.custom_entry = frame_opts.custom_entry
    frame._cfg_db = frame_opts.cfg_db

    M.apply_tooltip_panel_backdrop(frame)

    frame:SetMovable(true)
    frame:SetResizable(true)
    frame:EnableMouse(true)
    frame:SetClampedToScreen(true)
    frame:SetScript("OnEnter", handle_frame_mouse_enter)
    frame:SetScript("OnLeave", handle_frame_mouse_leave)
    if frame.SetResizeBounds then
        frame:SetResizeBounds(M.MIN_FRAME_WIDTH, M.MIN_FRAME_HEIGHT)
    end
    local cfg_db = frame._cfg_db or M.db
    local initial_width = cfg_db["width_"..category] or cfg_db["width"] or M.DEFAULT_FRAME_WIDTH
    if initial_width < M.MIN_FRAME_WIDTH then initial_width = M.MIN_FRAME_WIDTH end
    frame:SetSize(initial_width, 50)

    M.apply_saved_frame_position(frame, scale_key, is_debuff and -25 or 75)

    frame.move_handle = create_aura_frame_move_handle(frame, display_name, scale_key)
    create_aura_frame_resizer(frame, category)

    local managed_backend
    if category == "debuff" then
        managed_backend = M.create_managed_debuff_backend(frame, cfg_db)
    elseif category == "short" then
        managed_backend = M.create_managed_short_buff_backend(frame, cfg_db)
    elseif category == "static_long" then
        managed_backend = M.create_managed_learned_buff_backend(frame, cfg_db)
    elseif category == "timed" then
        managed_backend = M.create_managed_timed_buff_backend(frame, cfg_db)
    end

    -- Managed presets need one addon-owned mock visual for Test Aura. CDM frames
    -- retain their full pool for Cooldown Mode but share the managed preview cell.
    create_aura_icon_pool(frame, cfg_db, category, managed_backend and 1 or nil)
    if not managed_backend then
        if M.WOW_COOLDOWN_CATEGORIES[category] then
            M.create_managed_cdm_backend(frame, cfg_db, category)
        end
    end
    if managed_backend or frame._managed_cdm_backend then
        M.initialize_managed_test_preview_background(frame)
    end

    -- Map-based aura cache: auraInstanceID → entry table. Persists across events.
    frame._aura_map = {}

    -- Store parameters on frame itself for robust access during callbacks
    frame.update_params = create_aura_frame_update_params(
        show_key,
        move_key,
        timer_key,
        bg_key,
        scale_key,
        spacing_key,
        category,
        frame_opts.aura_filter or (is_debuff and "HARMFUL" or "HELPFUL")
    )

    -- New frames are shown by default. Keep every shell and move control hidden
    -- until update_auras() applies the saved enabled/move state; disabled frames
    -- intentionally skip their startup event work.
    frame:Hide()
    frame.move_handle:Hide()
    frame.resizer:Hide()

    bind_aura_frame_events(frame, category)

    register_runtime_frame(show_key, frame)
    return frame
end

--#endregion AURA FRAME EVENTS =================================================

--#region CUSTOM FRAME LIFECYCLE ===============================================

-- Builds the WoW frame for a custom entry. Called at load (for saved entries)
-- and at runtime (when user clicks + Custom). The frame is keyed by entry.id.
function M.create_custom_frame(entry)
    if not entry or not entry.id then return end
    addon.apply_defaults(M.CUSTOM_FRAME_TEMPLATE, entry)
    local id       = entry.id
    local show_key = "show_" .. id  -- e.g. "show_custom_1"
    M.rebuild_shared_options_group()
    entry.aura_base_filter = entry.aura_base_filter == "HARMFUL" and "HARMFUL" or "HELPFUL"
    local aura_filter = M.get_custom_aura_filter(entry)

    -- Custom frames use flat keys ("timer", "bg", etc.) inside the entry table,
    -- not the prefixed pattern used by preset frames.
    local frame = M.create_aura_frame(
        show_key,
        "move",
        "timer",
        "bg",
        "scale",
        "spacing",
        entry.name or id,
        aura_filter:find("HARMFUL", 1, true) ~= nil,
        {
            is_custom = true,
            custom_entry = entry,
            cfg_db = entry,
            aura_filter = aura_filter,
        }
    )

    M.update_auras(frame, show_key, "move", "timer", "bg", "scale", "spacing", aura_filter)

    return frame
end

-- Creates a new entry, persists it to DB, builds the WoW frame, and returns the entry.
function M.spawn_custom_frame()
    if not M.db then return nil end
    M.db.custom_frames = M.db.custom_frames or {}
    if #M.db.custom_frames >= M.MAX_CUSTOM_FRAMES then return nil end

    local entry = M.new_custom_entry()
    table.insert(M.db.custom_frames, entry)
    M.create_custom_frame(entry)
    return entry
end

-- Hides and fully removes a custom frame by id. Removes DB entry.
function M.destroy_custom_frame(id)
    if not id then return end
    local show_key = "show_" .. id
    local frame = unregister_runtime_frame(show_key)
    if frame then
        M.cancel_frame_ooc_fade(frame)
        stop_frame_hover_check(frame)
        frame._display_count = 0
        frame._tooltip_cache_retry_count = 0
        frame._tooltip_cache_retry_pending = false
        frame:Hide()
        frame:UnregisterAllEvents()
        frame:SetScript("OnEvent", nil)
        M.refresh_visible_icon_ticker()
    end
    if M.db and M.db.custom_frames then
        for i, entry in ipairs(M.db.custom_frames) do
            if entry.id == id then
                table.remove(M.db.custom_frames, i)
                break
            end
        end
    end
    local prefix = "custom_" .. id .. "_"
    for key in pairs(M.controls) do
        if type(key) == "string" and key:sub(1, #prefix) == prefix then
            M.controls[key] = nil
        end
    end
    M.controls["shared_options:bg:" .. id] = nil
    M.controls["bar_color_sync:" .. id] = nil
    M.controls["text_color_sync:" .. id] = nil
    M.clear_custom_aura_scan_cache()
    M.rebuild_shared_options_group()
end

--#endregion CUSTOM FRAME LIFECYCLE ============================================

--#region STARTUP ORCHESTRATION ================================================

local function prepare_aura_frame_db()
    ---@diagnostic disable-next-line: undefined-global
    local saved_db = Ls_Tweeks_DB
    if not saved_db.aura_frames then saved_db.aura_frames = {} end
    M.db = saved_db.aura_frames
    M.refresh_cdm_default_positions()
    if M.defaults then addon.apply_defaults(M.defaults, M.db) end
    M.normalize_saved_colors(M.db)
    M.apply_cdm_default_positions_to_db()
end

local function create_startup_aura_frames()
    for _, frame_def in ipairs(M.FRAME_DEFS) do
        local keys = M.get_preset_keys(frame_def.key)
        M.create_aura_frame(
            keys.show_key,
            keys.move_key,
            keys.timer_key,
            keys.bg_key,
            keys.scale_key,
            keys.spacing_key,
            frame_def.frame_label or frame_def.label,
            frame_def.is_debuff
        )
    end

    if M.db.custom_frames then
        for _, entry in ipairs(M.db.custom_frames) do
            M.create_custom_frame(entry)
        end
    end
end

local function ensure_module_started()
    if M._module_started then return end
    if not M.db then prepare_aura_frame_db() end
    create_startup_aura_frames()
    M._module_started = true
end

local function register_aura_frame_settings()
    addon.register_category("Buffs & Debuffs", function(parent) M.BuildSettings(parent) end, {
        order = 500,
        module_key = M.MODULE_KEY,
    })
end

local function start_aura_frame_runtime_services()
    M._module_runtime_enabled = true
    M.install_cdm_layout_refresh_hook()
    M.start_learned_buff_listener()
    M.set_managed_aura_runtime_enabled(true)
    -- Managed presentation owns no PLAYER_ENTERING_WORLD handler, so startup
    -- explicitly applies saved shell state after enabling the engine. The
    -- separate learned-buff listener only refreshes its native inclusion map.
    M.refresh_managed_preset_frames()
    M.apply_blizz_aura_frame_settings()
    M.update_all_blizz_cdm_visibility()
    M.queue_wow_cooldown_refresh("startup")

    if M.db.show_grid then
        M.create_grid_overlay()
    end
end

local function restore_cdm_viewer_visibility()
    if not M._cd_viewer_state then return end
    for frame, state in pairs(M._cd_viewer_state) do
        if frame and state and state.forced_hidden then
            state.forced_hidden = nil
            if frame.SetAlpha then frame:SetAlpha(1) end
            if frame.EnableMouse then frame:EnableMouse(true) end
            if (not InCombatLockdown or not InCombatLockdown()) and frame.Show then
                pcall(frame.Show, frame)
            end
        end
    end
end

local function stop_aura_frame_runtime_services()
    M._module_runtime_enabled = false
    M.stop_learned_buff_listener()
    M.set_managed_aura_runtime_enabled(false)
    M.stop_visible_icon_ticker()
    M.set_grid_visible(false)
    M.restore_blizz_aura_frame_settings()
    M.restore_blizz_cdm_viewer_settings()
    restore_cdm_viewer_visibility()

    for _, frame in ipairs(M.frames_list) do
        if frame then
            M.cancel_frame_ooc_fade(frame)
            stop_frame_hover_check(frame)
            frame:UnregisterAllEvents()
            frame:SetScript("OnEvent", nil)
            frame:Hide()
            if frame.move_handle then frame.move_handle:Hide() end
            if frame.resizer then frame.resizer:Hide() end
            frame._display_count = 0
        end
    end
end

function M.stop_runtime()
    stop_aura_frame_runtime_services()
end

local function rebind_existing_aura_frames()
    for _, frame in ipairs(M.frames_list) do
        if frame and frame.update_params then
            bind_aura_frame_events(frame, frame.category)
            local p = frame.update_params
            M.invalidate_frame_runtime_config(frame)
            M.update_auras(frame, p.show_key, p.move_key, p.timer_key, p.bg_key, p.scale_key, p.spacing_key, p.aura_filter)
        end
    end
end

function M.set_module_enabled(enabled)
    if enabled then
        M.invalidate_aura_scan_caches()

        ensure_module_started()
        start_aura_frame_runtime_services()
        rebind_existing_aura_frames()
        return
    end

    M.stop_runtime()
end

local function count_aura_runtime_status()
    local frame_count = 0
    local shown_count = 0
    local event_script_count = 0
    local scan_pending_count = 0
    local hover_ticker_count = 0
    for _, frame in ipairs(M.frames_list) do
        if frame then
            frame_count = frame_count + 1
            if frame.IsShown and frame:IsShown() then
                shown_count = shown_count + 1
            end
            if frame.GetScript and frame:GetScript("OnEvent") then
                event_script_count = event_script_count + 1
            end
            if frame._scan_pending then
                scan_pending_count = scan_pending_count + 1
            end
            if frame._hover_check_ticker then
                hover_ticker_count = hover_ticker_count + 1
            end
        end
    end

    local cdm_forced_hidden_count = 0
    for _, state in pairs(M._cd_viewer_state or {}) do
        if state and state.forced_hidden then
            cdm_forced_hidden_count = cdm_forced_hidden_count + 1
        end
    end

    return frame_count, shown_count, event_script_count, scan_pending_count, hover_ticker_count, cdm_forced_hidden_count
end

addon.register_module_status(M.MODULE_KEY, function()
    local frame_count, shown_count, event_script_count, scan_pending_count, hover_ticker_count, cdm_forced_hidden_count =
        count_aura_runtime_status()
    local fields = {
        "runtime=" .. tostring(M._module_runtime_enabled == true),
        "frames=" .. tostring(frame_count),
        "shown=" .. tostring(shown_count),
        "event_scripts=" .. tostring(event_script_count),
        "visible_icon_ticker=" .. tostring(M._visible_icon_ticker ~= nil),
        "scan_pending=" .. tostring(scan_pending_count),
        "hover_tickers=" .. tostring(hover_ticker_count),
        "cdm_forced_hidden=" .. tostring(cdm_forced_hidden_count),
        "grid=" .. tostring(M.grid_frame and M.grid_frame:IsShown() == true),
        "shared_options=" .. tostring(M.db and M.db.shared_options_enabled == true),
        "shared_test_auras=" .. tostring(M.is_shared_test_aura_enabled()),
        "disable_ooc_fade=" .. tostring(M.db and M.db.disable_ooc_fade == true),
    }
    for _, field in ipairs(M.get_managed_aura_status_fields()) do
        fields[#fields + 1] = field
    end
    local suppressed, suppression_error = M.get_blizz_aura_suppression_status()
    fields[#fields + 1] = "blizz_aura_suppressed=" .. tostring(suppressed)
    if suppression_error then
        fields[#fields + 1] = "blizz_aura_error=" .. suppression_error
    end
    return fields
end)

-- Startup conductor: keep addon-loaded work in order while each step
-- owns one broad responsibility.
local loader = CreateFrame("Frame")
loader:RegisterEvent("ADDON_LOADED")
loader:SetScript("OnEvent", function(self, _, name)
    if name == addon_name then
        -- Settings remain available while the module is disabled, so attach and
        -- normalize their saved data independently from frame/runtime startup.
        prepare_aura_frame_db()
        register_aura_frame_settings()
        if M.is_runtime_enabled() then
            ensure_module_started()
            start_aura_frame_runtime_services()
        else
            M.stop_runtime()
        end
        self:UnregisterEvent("ADDON_LOADED")
    end
end)

--#endregion STARTUP ORCHESTRATION =============================================

--#region RESET ORCHESTRATION ==================================================

local function apply_reset_runtime_state()
    M.apply_blizz_aura_frame_settings()
    M.update_all_blizz_cdm_visibility()
    M.apply_number_font_to_all()
    M.set_grid_visible(M.db.show_grid == true)
end

local function remove_orphan_custom_frames_after_reset()
    local valid_custom_ids = {}
    for _, entry in ipairs(M.db.custom_frames or {}) do
        if entry.id then valid_custom_ids[entry.id] = true end
    end
    local orphan_custom_ids = {}
    for show_key, frame in pairs(M.frames) do
        if frame.is_custom then
            local id = frame.custom_entry and frame.custom_entry.id or show_key:match("^show_(.+)$")
            if id and not valid_custom_ids[id] then
                orphan_custom_ids[#orphan_custom_ids + 1] = id
            end
        end
    end
    for _, id in ipairs(orphan_custom_ids) do
        M.destroy_custom_frame(id)
    end
end

local function find_saved_custom_entry(id)
    if not (id and M.db and M.db.custom_frames) then return nil end
    for _, entry in ipairs(M.db.custom_frames) do
        if entry.id == id then return entry end
    end
    return nil
end

local function refresh_frame_after_reset(frame)
    local p = frame.update_params
    if not p then return end

    M.invalidate_frame_runtime_config(frame)

    -- Re-link custom entry reference in case DB was replaced by reset.
    if frame.is_custom and frame.custom_entry then
        local entry = find_saved_custom_entry(frame.custom_entry.id)
        if entry then
            frame.custom_entry = entry
        end
        p.aura_filter = M.get_custom_aura_filter(frame.custom_entry)
    end

    M.update_auras(frame, p.show_key, p.move_key, p.timer_key, p.bg_key, p.scale_key, p.spacing_key, p.aura_filter)
end

local function refresh_aura_frames_after_reset()
    local frames_list = M.frames_list
    if not frames_list then return end
    for i = 1, #frames_list do
        local frame = frames_list[i]
        refresh_frame_after_reset(frame)
    end
end

local function refresh_aura_frame_settings_after_reset()
    M.sync_general_controls_from_db()
    if M.refresh_profiles_tab then
        M.refresh_profiles_tab()
    end
    if M.refresh_frames_tree then
        M.refresh_frames_tree()
    end
end

-- RESET AND REFRESH: Restores UI states following an Aura Frames settings reset.
function M.on_reset_complete()
    -- Reset conductor: recover runtime state, reconcile frame ownership, then
    -- refresh visible frames and settings controls from the replaced DB.
    apply_reset_runtime_state()
    M.note_learned_buff_cache_replaced()
    M.queue_learned_buff_scan()
    remove_orphan_custom_frames_after_reset()
    refresh_aura_frames_after_reset()
    refresh_aura_frame_settings_after_reset()
    M.restart_visible_icon_ticker()
end

--#endregion RESET ORCHESTRATION ===============================================
