-- Aura frame configuration schema and mode-aware value resolution.
-- Owns profile field lists plus Icon/Bar growth keys, defaults, and reads so
-- GUI, profiles, and runtime layout do not repeat frame configuration rules.

local _, addon = ...

addon.aura_frames = {
    _cdm_refresh_pending = {},
    _managed_aura_backends = {},
    _test_preview_paused_times = {},
    _test_preview_started = {},
    _test_preview_time_offsets = {},
    _tooltip_data_lines_cache = {},
    controls = {},
    frames = {},
    frames_list = {},
    grid_lines = {},
}
local M = addon.aura_frames

--#region PROFILE SCHEMA ======================================================

-- Canonical text-option family. Defaults, local/shared pickers, runtime,
-- normalization, and profile schemas all consume this list.
M.TEXT_OPTION_DEFS = {
    {
        text_type = "bar", label = "Bar Text", role = "body",
        local_prefix = "bar_text", color_key = "bar_text_color",
        default_size = 10, default_outline = false, max_size = 24,
        shared_control_key = "shared_options_bar_font_picker",
    },
    {
        text_type = "timer", label = "Timer Text", role = "timer",
        local_prefix = "timer_number", color_key = "timer_color",
        default_size = 10, default_outline = true, max_size = 18,
        shared_control_key = "shared_options_timer_font_picker",
    },
    {
        text_type = "stack", label = "Stack Text", role = "stack",
        local_prefix = "stack_number", color_key = "stack_color",
        default_size = 10, default_outline = true, max_size = 18,
        shared_control_key = "shared_options_stack_font_picker",
    },
}
M.TEXT_OPTION_DEFS_BY_TYPE = {}
for _, text_def in ipairs(M.TEXT_OPTION_DEFS) do
    text_def.popup_label = text_def.label .. " Options"
    text_def.shared_prefix = "shared_" .. text_def.text_type .. "_text"
    text_def.shared_font_key = text_def.shared_prefix .. "_font"
    M.TEXT_OPTION_DEFS_BY_TYPE[text_def.text_type] = text_def
end

M.PRESENTATION_PROFILE_CATEGORY_PREFIXES = {
    "show", "move", "move_bg_opt_out", "timer", "timer_swipe", "tooltip", "bg", "scale", "spacing", "width", "bar_mode",
    "color", "bar_bg_color", "fade_ooc", "ooc_alpha", "fade_delay", "fade_length", "bg_color",
    "growth_icon", "growth_bar", "test_aura", "cooldown_mode", "hide_blizz_cdm",
    "sync_bar_bg", "sync_bar_color", "sync_text_color", "sync_text_font",
}

M.CUSTOM_PRESENTATION_PROFILE_KEYS = {
    "show", "move", "move_bg_opt_out", "timer", "timer_swipe", "tooltip", "bg", "scale", "spacing", "width", "bar_mode",
    "color", "bar_bg_color", "fade_ooc", "ooc_alpha", "fade_delay", "fade_length", "bg_color",
    "growth_icon", "growth_bar", "test_aura", "sync_bar_bg", "sync_bar_color", "sync_text_color", "sync_text_font",
}

for _, text_def in ipairs(M.TEXT_OPTION_DEFS) do
    for _, keys in ipairs({ M.PRESENTATION_PROFILE_CATEGORY_PREFIXES, M.CUSTOM_PRESENTATION_PROFILE_KEYS }) do
        keys[#keys + 1] = text_def.color_key
        keys[#keys + 1] = text_def.local_prefix .. "_font"
        keys[#keys + 1] = text_def.local_prefix .. "_font_size"
        keys[#keys + 1] = text_def.local_prefix .. "_font_bold"
        keys[#keys + 1] = text_def.local_prefix .. "_font_outline"
    end
end

--#endregion PROFILE SCHEMA ===================================================

--#region GROWTH SETTINGS =====================================================

function M.apply_presentation_growth_defaults(defaults, frame_defs)
    if not defaults then return end
    for _, frame_def in ipairs(frame_defs or {}) do
        local growth = frame_def.growth
        defaults["growth_icon_" .. frame_def.key] = growth.icon
        defaults["growth_bar_" .. frame_def.key] = growth.bar
    end
end

function M.apply_custom_presentation_growth_defaults(template)
    if not template then return end
    template.growth_icon = "DOWN"
    template.growth_bar = "DOWN"
end

function M.get_growth_logical_key(bar_mode)
    return bar_mode and "growth_bar" or "growth_icon"
end

local function normalize_bar_growth(growth)
    local direction = addon.GetGrowthDirection(growth)
    return direction.vertical and direction.value or "DOWN"
end

function M.get_mode_growth(cfg_db, category, bar_mode)
    local mode_key = M.get_growth_logical_key(bar_mode)
    local fallback
    if bar_mode then
        fallback = cfg_db and cfg_db ~= M.db
            and M.CUSTOM_FRAME_TEMPLATE[mode_key]
            or M.defaults[mode_key .. "_" .. category]
    else
        fallback = "RIGHT"
    end
    local growth = M.get_setting(cfg_db, category, mode_key, fallback)
    if bar_mode then return normalize_bar_growth(growth) end
    return addon.GetGrowthDirection(growth).value
end

--#endregion GROWTH SETTINGS ==================================================
