-- Settings UI for the Skyriding Vigor module.
-- Owns control construction and synchronization from the Skyriding Vigor DB.
-- Runtime behavior and DB mutation helpers live in sv_main.lua.
local addon_name, addon = ...

local M = addon.skyriding_vigor

local CreateFrame = CreateFrame
local InCombatLockdown = InCombatLockdown

--#region CONFIGURATION ========================================================

local SLIDER_WITH_BOX_SIZE = addon.SLIDER_WITH_BOX_SIZE

local UI_CONFIG = {
    title_offset_x = 20,
    title_offset_y = -20,
    row_gap_y = 18,
    slider_gap_x = 18,
    slider_width = SLIDER_WITH_BOX_SIZE.width,
    color_picker_width = 95,
    button_height = 22,
    button_padding_x = 24,
    race_profile_panel_padding_x = 8,
    race_profile_panel_padding_y = 8,
    slider_offset_y = -14,
    slider_row_height = SLIDER_WITH_BOX_SIZE.height + 20,
    slider_row_gap_y = 0,
    grid_row_gap = 20,
}

local ROWS = {
    top = 1,
    position = 2,
    decor = 3,
    fade = 4,
    spark = 5,
}

local CONTROL_GRID = {
    enabled = { row = ROWS.top, col = 1 },
    skyriding_talents = { row = ROWS.spark, col = 5, center = true },
    fill_test = { row = ROWS.top, col = 2, center = true },
    fill_color = {
        row = ROWS.top,
        col = 2,
        y = -(UI_CONFIG.button_height + UI_CONFIG.row_gap_y),
        width = UI_CONFIG.color_picker_width,
        center = true,
    },
    fill_add = { row = ROWS.top, col = 3 },
    style = { row = ROWS.top, col = 4, center = true },
    node_color = { row = ROWS.top, col = 5, center = true },

    move_mode = { row = ROWS.position, col = 1 },
    snap_to_grid = { x = 0, y = -8 },
    reset_position = { x = 0, y = -8, center = true },
    x_position = { row = ROWS.position, col = 2 },
    y_position = { row = ROWS.position, col = 3 },
    scale = { row = ROWS.position, col = 4 },
    spacing = { row = ROWS.position, col = 5 },

    decor_style = { row = ROWS.decor, col = 1, y = -25, center = true },
    decor_color = { row = ROWS.decor, col = 2, y = -25, center = true },
    decor_x_position = { row = ROWS.decor, col = 3 },
    decor_y_position = { row = ROWS.decor, col = 4 },
    decor_scale = { row = ROWS.decor, col = 5 },

    fade_when_full = { row = ROWS.fade, col = 1 },
    fade_alpha = { row = ROWS.fade, col = 2 },
    fade_length = { row = ROWS.fade, col = 3 },
    progress_update_hz = { row = ROWS.fade, col = 5 },

    show_spark = { row = ROWS.spark, col = 1 },
    spark_color = { row = ROWS.spark, col = 2, width = UI_CONFIG.color_picker_width, center = true },
    spark_size = { row = ROWS.spark, col = 3 },
    race_profile_panel = { row = ROWS.top, col = 1, y = -32, center = true },
    race_profile_test = { x = 0, y = -8 },
}

local STRINGS = {
    enabled = "Enable Vigor Bar",
    fade_when_full = "Fade When Full",
    fade_when_full_tooltip = "Visible while flying or filling. \nFades when full and idle.",
    fade_alpha = "Fade Alpha",
    fade_length = "Fade Length",
    progress_update_hz = "Fill FPS",
    show_spark = "Show Spark",
    spark_color = "Spark Color",
    spark_size = "Spark Thickness",
    move_mode = "Move Mode",
    snap_to_grid = "Snap to Grid",
    style = "Style",
    node_color = "Node Color",
    fill_color = "Fill Color",
    fill_add = "Fill Brightness",
    decor_style = "End Decor",
    decor_color = "Decor Color",
    decor_x_position = "End Decor X",
    decor_y_position = "End Decor Y",
    decor_scale = "End Decor Scale",
    spacing = "Node Spacing",
    scale = "Scale",
    x_position = "X Position",
    y_position = "Y Position",
    fill_test = "Start Fill Test",
    stop_fill_test = "Stop Fill Test",
    race_profile_enabled = "Race Profile",
    race_profile_test = "Start Race Test",
    stop_race_profile_test = "Stop Race Test",
    skyriding_talents = "Skyriding Talents",
}

--#endregion CONFIGURATION =====================================================

--#region SHARED HELPERS =======================================================

local function get_setting_range(key)
    local range = M.SETTING_RANGES[key]
    if not range then
        error("LsTweaks Skyriding Vigor missing setting range: " .. tostring(key), 2)
    end
    return range
end

local function set_setting_from_slider(key)
    return function(value)
        if M._syncing_slider_controls then return end
        M.set_db_value(key, value)
    end
end

local function create_control_panel(parent)
    return addon.CreateControlPanel(parent)
end

local function register_flight_locked_control(control, is_enabled)
    if not control then return control end
    M.flight_locked_controls[#M.flight_locked_controls + 1] = {
        control = control,
        is_enabled = is_enabled,
    }
    return control
end

local function size_panel_to_controls(panel, cfg, ...)
    local max_width = 0
    local total_height = 0
    for i = 1, select("#", ...) do
        local control = select(i, ...)
        if control then
            max_width = math.max(max_width, control:GetWidth() or 0)
            total_height = total_height + (control:GetHeight() or 0)
        end
    end

    local control_gap = math.abs(CONTROL_GRID.race_profile_test.y or 0)
    panel:SetSize(
        max_width + (cfg.race_profile_panel_padding_x * 2),
        total_height + control_gap + (cfg.race_profile_panel_padding_y * 2)
    )
end

local function sync_race_profile_panel_size()
    local controls = M.controls
    if not controls or not controls.race_profile_panel then return end
    size_panel_to_controls(
        controls.race_profile_panel,
        UI_CONFIG,
        controls.race_profile_container,
        controls.race_profile_test_button
    )
    if M.settings_grid then
        M.settings_grid:center(controls.race_profile_panel, CONTROL_GRID.race_profile_panel)
    end
end

local function place_grid_control(frame, placement, place_opts)
    if M.settings_grid then
        M.settings_grid:place(frame, placement, nil, place_opts)
    end
end

local function open_skyriding_talents()
    if InCombatLockdown and InCombatLockdown() then
        print("|cFFFFFF00LsTweaks: Cannot open Skyriding Talents while in combat. Try again out of combat.|r")
        return
    end

    if GenericTraitUI_LoadUI then
        GenericTraitUI_LoadUI()
    end

    if GenericTraitFrame and Constants and Constants.MountDynamicFlightConsts
        and GenericTraitFrame.SetConfigIDBySystemID and GenericTraitFrame.SetTreeID
    then
        GenericTraitFrame:SetConfigIDBySystemID(Constants.MountDynamicFlightConsts.TRAIT_SYSTEM_ID)
        GenericTraitFrame:SetTreeID(Constants.MountDynamicFlightConsts.TREE_ID)
        if ToggleFrame then
            ToggleFrame(GenericTraitFrame)
        elseif GenericTraitFrame.Show then
            GenericTraitFrame:Show()
        end
        return
    end

    print("|cFFFFFF00LsTweaks:|r Skyriding Talents UI is not available.")
end

--#endregion SHARED HELPERS ====================================================

--#region CONTROL SYNCHRONIZATION ==============================================

local set_control_enabled
local FADE_CONTROL_KEYS = { "fade_when_full", "fade_alpha", "fade_length" }

function M.sync_fill_test_button()
    local button = M.controls.fill_test_button
    if button then
        local width = button:SetTextToFit(M._fill_test_enabled and STRINGS.stop_fill_test or STRINGS.fill_test)
        if M.controls_parent then
            place_grid_control(button, CONTROL_GRID.fill_test, { width = width })
        end
    end
    if button then
        set_control_enabled(button, M._fill_test_enabled or not (M.is_settings_locked_by_flight()))
    end
end

function M.sync_race_profile_controls(root_db)
    root_db = root_db or (M.get_root_db())
    local checkbox = M.controls.race_profile_enabled
    if checkbox then
        checkbox:SetCheckedSilently(root_db and root_db.race_profile_enabled or false)
    end

    local button = M.controls.race_profile_test_button
    if button then
        button:SetTextToFit(M._race_profile_test_enabled and STRINGS.stop_race_profile_test or STRINGS.race_profile_test)
    end
    local race_test_enabled = root_db and root_db.race_profile_enabled
        and not (M.is_settings_locked_by_flight())
    set_control_enabled(button, race_test_enabled)
    sync_race_profile_panel_size()
    M.sync_fade_controls_enabled()
end

function M.sync_fade_controls_enabled()
    local controls = M.controls
    if not controls then return end

    local enabled = not (M.is_settings_locked_by_flight())
        and not (M.is_race_profile_active())
    for i = 1, #FADE_CONTROL_KEYS do
        local control = controls[FADE_CONTROL_KEYS[i]]
        if control then
            if control.SetEnabled then
                control:SetEnabled(enabled)
            elseif enabled and control.Enable then
                control:Enable()
            elseif not enabled and control.Disable then
                control:Disable()
            end
        end
    end
end

set_control_enabled = function(control, enabled)
    if not control then return end
    if control.SetEnabled then
        control:SetEnabled(enabled)
    elseif enabled and control.Enable then
        control:Enable()
    elseif not enabled and control.Disable then
        control:Disable()
    end
end

local function get_registered_control_enabled(entry, flight_locked)
    local enabled = not flight_locked
    if enabled and entry.is_enabled then
        enabled = entry.is_enabled() and true or false
    end
    return enabled
end

local function sync_registered_control_enabled(control)
    local controls = M.flight_locked_controls
    if not controls then return end

    local flight_locked = M.is_settings_locked_by_flight() or false
    for i = 1, #controls do
        local entry = controls[i]
        if entry.control == control then
            set_control_enabled(control, get_registered_control_enabled(entry, flight_locked))
            return
        end
    end
end

local function run_with_sync_guard(guard_key, callback)
    M[guard_key] = true
    local ok, err = pcall(callback)
    M[guard_key] = nil
    if not ok then
        error(err, 0)
    end
end

function M.sync_settings_controls_enabled(force)
    local flight_locked = M.is_settings_locked_by_flight()
    if not force and M._settings_controls_flight_locked == flight_locked then return end
    M._settings_controls_flight_locked = flight_locked

    local controls = M.flight_locked_controls
    for i = 1, #controls do
        local entry = controls[i]
        set_control_enabled(entry.control, get_registered_control_enabled(entry, flight_locked))
    end

    M.sync_fade_controls_enabled()
end

function M.sync_position_controls(db)
    local position = db and db.position
    if not position then return end

    local x_slider = M.controls.x_position
    if x_slider and position.x ~= nil and x_slider:GetValue() ~= position.x then
        run_with_sync_guard("_syncing_position_controls", function()
            x_slider:SetValueSilently(position.x)
        end)
    end

    local y_slider = M.controls.y_position
    if y_slider and position.y ~= nil and y_slider:GetValue() ~= position.y then
        run_with_sync_guard("_syncing_position_controls", function()
            y_slider:SetValueSilently(position.y)
        end)
    end
end

function M.sync_slider_controls(db)
    if not db then return end
    local defaults = M.DEFAULTS

    run_with_sync_guard("_syncing_slider_controls", function()
        for _, key in ipairs(M.SLIDER_KEYS) do
            local control = M.controls[key]
            if control then
                local value
                if key == "scale" then
                    value = M.get_style_scale()
                elseif key == "fill_add_alpha" then
                    value = M.get_style_fill_add_alpha()
                else
                    value = db[key]
                end
                if value == nil then value = defaults[key] end
                if value ~= nil and control:GetValue() ~= value then
                    control:SetValueSilently(value)
                end
            end
        end
    end)
end

function M.sync_decor_position_controls(db)
    db = db or (M.get_db())
    if not db then return end

    local x_slider = M.controls.decor_x_position
    if x_slider then
        local value = M.get_decor_position_axis("x")
        if value ~= nil and x_slider:GetValue() ~= value then
            x_slider:SetValueSilently(value)
        end
    end

    local y_slider = M.controls.decor_y_position
    if y_slider then
        local value = M.get_decor_position_axis("y")
        if value ~= nil and y_slider:GetValue() ~= value then
            y_slider:SetValueSilently(value)
        end
    end

    local scale_slider = M.controls.decor_scale
    if scale_slider then
        local value = M.get_decor_scale()
        if value ~= nil and scale_slider:GetValue() ~= value then
            scale_slider:SetValueSilently(value)
        end
    end
end

function M.sync_style_color_controls()
    local picker = M.controls.fill_color
    if picker then
        picker:SetValue(M.get_style_fill_color())
    end
end

function M.sync_spark_color_controls()
    local picker = M.controls.spark_color
    if picker then
        picker:SetValue(M.get_spark_color())
    end
end

function M.sync_node_color_controls()
    local dropdown = M.controls.node_color
    if dropdown then
        dropdown:SetValue(M.get_node_color())
        sync_registered_control_enabled(dropdown)
    end
end

function M.sync_decor_color_controls()
    local dropdown = M.controls.decor_color
    if dropdown then
        dropdown:SetValue(M.get_decor_color())
        sync_registered_control_enabled(dropdown)
    end
end

function M.sync_settings_controls(db)
    db = db or (M.get_db())
    if not db then return end

    local defaults = M.DEFAULTS
    local enabled_cb = M.controls.enabled
    if enabled_cb then
        enabled_cb:SetCheckedSilently(db.enabled or false)
    end
    local fade_cb = M.controls.fade_when_full
    if fade_cb then
        fade_cb:SetCheckedSilently(db.fade_when_full or false)
    end
    local spark_cb = M.controls.show_spark
    if spark_cb then
        spark_cb:SetCheckedSilently(db.show_spark or false)
    end
    local move_cb = M.controls.move_mode
    if move_cb then
        move_cb:SetCheckedSilently(db.move_mode or false)
    end
    local snap_cb = M.controls.snap_to_grid
    if snap_cb then
        snap_cb:SetCheckedSilently(db.snap_to_grid or false)
    end
    local style_dropdown = M.controls.style
    if style_dropdown then
        style_dropdown:SetValue(db.style or defaults.style)
    end
    M.sync_node_color_controls()
    local decor_style_dropdown = M.controls.decor_style
    if decor_style_dropdown then
        decor_style_dropdown:SetValue(db.decor_style or defaults.decor_style)
    end
    M.sync_decor_color_controls()

    M.sync_slider_controls(db)
    M.sync_style_color_controls()
    M.sync_spark_color_controls()
    M.sync_decor_position_controls(db)
    M.sync_position_controls(db)
    M.sync_fill_test_button()
    M.sync_race_profile_controls()
    M.sync_settings_controls_enabled()
end

--#endregion CONTROL SYNCHRONIZATION ===========================================

--#region SETTINGS CONSTRUCTION ================================================

local function build_top_row(parent, context)
    local cfg = context.cfg
    local db = context.db
    local defaults = context.defaults

    local enabled_container = addon.CreateCheckbox(parent, STRINGS.enabled, db and db.enabled, function(is_checked)
        M.set_db_value("enabled", is_checked)
    end)
    M.controls.enabled = register_flight_locked_control(enabled_container)
    place_grid_control(enabled_container, CONTROL_GRID.enabled)

    local fill_test_button = addon.CreateTextButton(parent, M._fill_test_enabled and STRINGS.stop_fill_test or STRINGS.fill_test, function()
        M.toggle_fill_test()
    end, {
        fit_texts = { STRINGS.fill_test, STRINGS.stop_fill_test },
        height = cfg.button_height,
        padding_x = cfg.button_padding_x,
    })
    place_grid_control(fill_test_button, CONTROL_GRID.fill_test)
    M.controls.fill_test_button = register_flight_locked_control(fill_test_button)

    local style_dropdown = addon.CreateDropdown(
        addon_name .. "SkyridingVigorStyle",
        parent,
        STRINGS.style,
        M.BAR_STYLE_OPTIONS,
        {
            fit_to_text = true,
            text_padding_x = cfg.button_padding_x,
            get_value = function()
                local active_db = M.get_db()
                return active_db and active_db.style or defaults.style
            end,
            on_select = function(value)
                M.set_db_value("style", value)
            end,
        }
    )
    M.controls.style = register_flight_locked_control(style_dropdown)
    place_grid_control(style_dropdown, CONTROL_GRID.style)

    local node_color_dropdown = addon.CreateDropdown(
        addon_name .. "SkyridingVigorNodeColor",
        parent,
        STRINGS.node_color,
        M.NODE_COLOR_OPTIONS,
        {
            fit_to_text = true,
            text_padding_x = cfg.button_padding_x,
            get_value = function()
                return M.get_node_color() or M.NODE_COLOR_DEFAULT
            end,
            on_select = function(value)
                M.set_db_value("node_color", value)
            end,
        }
    )
    M.controls.node_color = register_flight_locked_control(node_color_dropdown, function()
        return M.bar_style_supports_node_color()
    end)
    place_grid_control(node_color_dropdown, CONTROL_GRID.node_color)
    M.sync_node_color_controls()

    local fill_color_proxy = setmetatable({}, {
        __index = function(_, key)
            if key == "fill_color" then
                return M.get_style_fill_color() or { r = 1, g = 1, b = 1, a = 1 }
            end
            return nil
        end,
        __newindex = function(_, key, value)
            if key == "fill_color" then
                M.set_style_fill_color(value)
            end
        end,
    })
    local fill_color_defaults_proxy = setmetatable({}, {
        __index = function(_, key)
            if key == "fill_color" then
                return M.get_style_fill_color_default() or { r = 1, g = 1, b = 1, a = 1 }
            end
            return nil
        end,
    })
    local fill_color_picker = addon.CreateColorPicker(parent, fill_color_proxy, "fill_color", true, STRINGS.fill_color, fill_color_defaults_proxy, function()
        M.apply_fill_color()
    end)
    M.controls.fill_color = register_flight_locked_control(fill_color_picker)
    place_grid_control(fill_color_picker, CONTROL_GRID.fill_color)

    local fill_add_proxy = setmetatable({}, {
        __index = function(_, key)
            if key == "fill_add_alpha" then
                return M.get_style_fill_add_alpha() or 0.5
            end
            return nil
        end,
        __newindex = function(_, key, value)
            if key == "fill_add_alpha" then
                M.set_style_fill_add_alpha(value)
            end
        end,
    })
    local fill_add_defaults_proxy = setmetatable({}, {
        __index = function(_, key)
            if key == "fill_add_alpha" then
                return M.get_style_fill_add_alpha_default() or 0.5
            end
            return nil
        end,
    })
    local fill_add_range = context.fill_add_range
    local fill_add_slider = addon.CreateSliderWithBox(
        addon_name .. "SkyridingVigorFillAdd",
        parent,
        STRINGS.fill_add,
        fill_add_range.min,
        fill_add_range.max,
        fill_add_range.step,
        fill_add_proxy,
        "fill_add_alpha",
        fill_add_defaults_proxy,
        function(value)
            M.set_style_fill_add_alpha(value)
        end,
        { display_decimals = 2 }
    )
    M.controls.fill_add_alpha = register_flight_locked_control(fill_add_slider)
    place_grid_control(fill_add_slider, CONTROL_GRID.fill_add)
end

local function build_position_row(parent, context)
    local db = context.db
    local defaults = context.defaults
    local active_profile_proxy = context.active_profile_proxy
    local position_proxy = context.position_proxy

    local move_container = addon.CreateCheckbox(parent, STRINGS.move_mode, db and db.move_mode, function(is_checked)
        M.set_db_value("move_mode", is_checked)
    end)
    M.controls.move_mode = register_flight_locked_control(move_container)
    place_grid_control(move_container, CONTROL_GRID.move_mode)

    local snap_container = addon.CreateCheckbox(parent, STRINGS.snap_to_grid, db and db.snap_to_grid, function(is_checked)
        M.set_snap_to_grid(is_checked)
    end)
    M.controls.snap_to_grid = register_flight_locked_control(snap_container)
    M.settings_grid:stack_below(snap_container, move_container, CONTROL_GRID.snap_to_grid)

    local reset_button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    reset_button:SetSize(110, 22)
    reset_button:SetText("Reset Position")
    addon.ApplyStandardButtonStyle(reset_button)
    M.settings_grid:stack_below(reset_button, snap_container, {
        x = CONTROL_GRID.reset_position.x,
        y = CONTROL_GRID.reset_position.y,
        width = reset_button:GetWidth(),
        center = true,
    })
    reset_button:SetScript("OnClick", M.reset_position)
    M.controls.reset_position = register_flight_locked_control(reset_button)

    if db then
        db.position = db.position or {}
    end
    local default_position = defaults.position

    local x_range = context.x_range
    local x_slider = addon.CreateSliderWithBox(
        addon_name .. "SkyridingVigorXPosition",
        parent,
        STRINGS.x_position,
        x_range.min,
        x_range.max,
        x_range.step,
        position_proxy,
        "x",
        default_position
    )
    x_slider:HookValueChanged(function(_, value)
        M.set_position_axis("x", value)
    end)
    M.controls.x_position = register_flight_locked_control(x_slider)
    place_grid_control(x_slider, CONTROL_GRID.x_position)

    local y_range = context.y_range
    local y_slider = addon.CreateSliderWithBox(
        addon_name .. "SkyridingVigorYPosition",
        parent,
        STRINGS.y_position,
        y_range.min,
        y_range.max,
        y_range.step,
        position_proxy,
        "y",
        default_position
    )
    y_slider:HookValueChanged(function(_, value)
        M.set_position_axis("y", value)
    end)
    M.controls.y_position = register_flight_locked_control(y_slider)
    place_grid_control(y_slider, CONTROL_GRID.y_position)

    local scale_range = context.scale_range
    local scale_slider = addon.CreateSliderWithBox(
        addon_name .. "SkyridingVigorScale",
        parent,
        STRINGS.scale,
        scale_range.min,
        scale_range.max,
        scale_range.step,
        active_profile_proxy,
        "scale",
        defaults,
        set_setting_from_slider("scale"),
        { display_decimals = 2, immediate_callback = true }
    )
    M.controls.scale = register_flight_locked_control(scale_slider)
    place_grid_control(scale_slider, CONTROL_GRID.scale)

    local spacing_range = context.spacing_range
    local spacing_slider = addon.CreateSliderWithBox(
        addon_name .. "SkyridingVigorSpacing",
        parent,
        STRINGS.spacing,
        spacing_range.min,
        spacing_range.max,
        spacing_range.step,
        active_profile_proxy,
        "spacing",
        defaults,
        set_setting_from_slider("spacing"),
        { immediate_callback = true }
    )
    M.controls.spacing = register_flight_locked_control(spacing_slider)
    place_grid_control(spacing_slider, CONTROL_GRID.spacing)
end

local function build_decor_row(parent, context)
    local cfg = context.cfg
    local defaults = context.defaults

    local decor_position_proxy = setmetatable({}, {
        __index = function(_, key)
            if key == "x" or key == "y" then
                return M.get_decor_position_axis(key) or 0
            elseif key == "scale" then
                return M.get_decor_scale() or 1
            end
            return nil
        end,
        __newindex = function(_, key, value)
            if key == "x" or key == "y" then
                M.set_decor_position_axis(key, value)
            elseif key == "scale" then
                M.set_decor_scale(value)
            end
        end,
    })
    local decor_position_defaults_proxy = setmetatable({}, {
        __index = function(_, key)
            if key == "x" or key == "y" then
                return M.get_decor_position_default(key) or 0
            elseif key == "scale" then
                return M.get_decor_scale_default() or 1
            end
            return nil
        end,
    })

    local decor_style_dropdown = addon.CreateDropdown(
        addon_name .. "SkyridingVigorDecorStyle",
        parent,
        STRINGS.decor_style,
        M.DECOR_STYLE_OPTIONS,
        {
            fit_to_text = true,
            text_padding_x = cfg.button_padding_x,
            get_value = function()
                local active_db = M.get_db()
                return active_db and active_db.decor_style or defaults.decor_style
            end,
            on_select = function(value)
                M.set_db_value("decor_style", value)
            end,
        }
    )
    M.controls.decor_style = register_flight_locked_control(decor_style_dropdown)
    place_grid_control(decor_style_dropdown, CONTROL_GRID.decor_style)

    local decor_color_dropdown = addon.CreateDropdown(
        addon_name .. "SkyridingVigorDecorColor",
        parent,
        STRINGS.decor_color,
        M.DECOR_COLOR_OPTIONS,
        {
            fit_to_text = true,
            text_padding_x = cfg.button_padding_x,
            get_value = function()
                return M.get_decor_color() or M.DECOR_COLOR_DEFAULT
            end,
            on_select = function(value)
                M.set_db_value("decor_color", value)
            end,
        }
    )
    M.controls.decor_color = register_flight_locked_control(decor_color_dropdown, function()
        local style_dropdown = M.controls.decor_style
        local style_key = style_dropdown and style_dropdown:GetValue() or nil
        return M.decor_style_supports_color(style_key)
    end)
    place_grid_control(decor_color_dropdown, CONTROL_GRID.decor_color)
    M.sync_decor_color_controls()

    local decor_x_range = context.decor_x_range
    local decor_x_slider = addon.CreateSliderWithBox(
        addon_name .. "SkyridingVigorDecorXPosition",
        parent,
        STRINGS.decor_x_position,
        decor_x_range.min,
        decor_x_range.max,
        decor_x_range.step,
        decor_position_proxy,
        "x",
        decor_position_defaults_proxy,
        function(value)
            M.set_decor_position_axis("x", value)
        end
    )
    M.controls.decor_x_position = register_flight_locked_control(decor_x_slider)
    place_grid_control(decor_x_slider, CONTROL_GRID.decor_x_position)

    local decor_y_range = context.decor_y_range
    local decor_y_slider = addon.CreateSliderWithBox(
        addon_name .. "SkyridingVigorDecorYPosition",
        parent,
        STRINGS.decor_y_position,
        decor_y_range.min,
        decor_y_range.max,
        decor_y_range.step,
        decor_position_proxy,
        "y",
        decor_position_defaults_proxy,
        function(value)
            M.set_decor_position_axis("y", value)
        end
    )
    M.controls.decor_y_position = register_flight_locked_control(decor_y_slider)
    place_grid_control(decor_y_slider, CONTROL_GRID.decor_y_position)

    local decor_scale_range = context.decor_scale_range
    local decor_scale_slider = addon.CreateSliderWithBox(
        addon_name .. "SkyridingVigorDecorScale",
        parent,
        STRINGS.decor_scale,
        decor_scale_range.min,
        decor_scale_range.max,
        decor_scale_range.step,
        decor_position_proxy,
        "scale",
        decor_position_defaults_proxy,
        nil,
        { display_decimals = 2 }
    )
    M.controls.decor_scale = register_flight_locked_control(decor_scale_slider)
    place_grid_control(decor_scale_slider, CONTROL_GRID.decor_scale)
end

local function build_fade_row(parent, context)
    local db = context.db
    local defaults = context.defaults
    local active_profile_proxy = context.active_profile_proxy

    local fade_container, fade_cb, fade_label = addon.CreateCheckbox(parent, STRINGS.fade_when_full, db and db.fade_when_full, function(is_checked)
        M.set_db_value("fade_when_full", is_checked)
    end)
    M.controls.fade_when_full = register_flight_locked_control(fade_container, function()
        return not (M.is_race_profile_active())
    end)
    place_grid_control(fade_container, CONTROL_GRID.fade_when_full)
    addon.AttachTooltipToTargets(STRINGS.fade_when_full_tooltip, fade_container, fade_cb, fade_label)

    local fade_alpha_range = context.fade_alpha_range
    local fade_alpha_slider = addon.CreateSliderWithBox(
        addon_name .. "SkyridingVigorFadeAlpha",
        parent,
        STRINGS.fade_alpha,
        fade_alpha_range.min,
        fade_alpha_range.max,
        fade_alpha_range.step,
        active_profile_proxy,
        "fade_alpha",
        defaults,
        set_setting_from_slider("fade_alpha"),
        { immediate_callback = true }
    )
    M.controls.fade_alpha = register_flight_locked_control(fade_alpha_slider, function()
        return not (M.is_race_profile_active())
    end)
    place_grid_control(fade_alpha_slider, CONTROL_GRID.fade_alpha)

    local fade_length_range = context.fade_length_range
    local fade_length_slider = addon.CreateSliderWithBox(
        addon_name .. "SkyridingVigorFadeLength",
        parent,
        STRINGS.fade_length,
        fade_length_range.min,
        fade_length_range.max,
        fade_length_range.step,
        active_profile_proxy,
        "fade_length",
        defaults,
        set_setting_from_slider("fade_length")
    )
    M.controls.fade_length = register_flight_locked_control(fade_length_slider, function()
        return not (M.is_race_profile_active())
    end)
    place_grid_control(fade_length_slider, CONTROL_GRID.fade_length)

    local progress_update_hz_range = context.progress_update_hz_range
    local progress_update_hz_slider = addon.CreateSliderWithBox(
        addon_name .. "SkyridingVigorProgressUpdateHz",
        parent,
        STRINGS.progress_update_hz,
        progress_update_hz_range.min,
        progress_update_hz_range.max,
        progress_update_hz_range.step,
        active_profile_proxy,
        "progress_update_hz",
        defaults,
        set_setting_from_slider("progress_update_hz")
    )
    M.controls.progress_update_hz = register_flight_locked_control(progress_update_hz_slider)
    place_grid_control(progress_update_hz_slider, CONTROL_GRID.progress_update_hz)
end

local function build_race_profile_panel(parent, context)
    local cfg = context.cfg
    local root_db = context.root_db

    local race_profile_panel = create_control_panel(parent)
    M.controls.race_profile_panel = race_profile_panel

    local race_profile_container = addon.CreateCheckbox(
        race_profile_panel,
        STRINGS.race_profile_enabled,
        root_db and root_db.race_profile_enabled,
        function(is_checked)
            M.set_race_profile_enabled(is_checked)
        end
    )
    M.controls.race_profile_enabled = register_flight_locked_control(race_profile_container)
    M.controls.race_profile_container = race_profile_container
    race_profile_container:SetPoint(
        "TOPLEFT",
        race_profile_panel,
        "TOPLEFT",
        cfg.race_profile_panel_padding_x,
        -cfg.race_profile_panel_padding_y
    )

    local race_profile_test_button = addon.CreateTextButton(race_profile_panel, M._race_profile_test_enabled and STRINGS.stop_race_profile_test or STRINGS.race_profile_test, function()
        M.toggle_race_profile_test()
    end, {
        fit_texts = { STRINGS.race_profile_test, STRINGS.stop_race_profile_test },
        height = cfg.button_height,
        padding_x = cfg.button_padding_x,
    })
    race_profile_test_button:SetPoint(
        "TOPLEFT",
        race_profile_container,
        "BOTTOMLEFT",
        CONTROL_GRID.race_profile_test.x,
        CONTROL_GRID.race_profile_test.y
    )
    M.controls.race_profile_test_button = register_flight_locked_control(race_profile_test_button, function()
        local active_root_db = M.get_root_db()
        return active_root_db and active_root_db.race_profile_enabled or false
    end)
    size_panel_to_controls(race_profile_panel, cfg, race_profile_container, race_profile_test_button)
    M.settings_grid:center(race_profile_panel, CONTROL_GRID.race_profile_panel)
    M.sync_race_profile_controls(root_db)
end

local function build_spark_row(parent, context)
    local cfg = context.cfg
    local db = context.db
    local defaults = context.defaults
    local active_profile_proxy = context.active_profile_proxy

    local skyriding_talents_button = addon.CreateTextButton(parent, STRINGS.skyriding_talents, open_skyriding_talents, {
        height = cfg.button_height,
        padding_x = cfg.button_padding_x,
    })
    place_grid_control(skyriding_talents_button, CONTROL_GRID.skyriding_talents)
    M.controls.skyriding_talents_button = skyriding_talents_button

    local spark_container = addon.CreateCheckbox(parent, STRINGS.show_spark, db and db.show_spark, function(is_checked)
        M.set_db_value("show_spark", is_checked)
    end)
    M.controls.show_spark = register_flight_locked_control(spark_container)
    place_grid_control(spark_container, CONTROL_GRID.show_spark)

    if db then
        db.spark_color = db.spark_color or { r = 1, g = 1, b = 1, a = 1 }
    end
    local spark_color_defaults = {
        spark_color = defaults.spark_color,
    }
    local spark_color_picker = addon.CreateColorPicker(parent, active_profile_proxy, "spark_color", true, STRINGS.spark_color, spark_color_defaults, function()
        M.set_db_value("show_spark", true)
        if M.controls.show_spark then
            M.controls.show_spark:SetCheckedSilently(true)
        end
        M.apply_spark_settings()
    end)
    M.controls.spark_color = register_flight_locked_control(spark_color_picker)
    place_grid_control(spark_color_picker, CONTROL_GRID.spark_color)

    local spark_size_range = context.spark_size_range
    local spark_size_slider = addon.CreateSliderWithBox(
        addon_name .. "SkyridingVigorSparkSize",
        parent,
        STRINGS.spark_size,
        spark_size_range.min,
        spark_size_range.max,
        spark_size_range.step,
        active_profile_proxy,
        "spark_size",
        defaults,
        set_setting_from_slider("spark_size"),
        { display_decimals = 2, immediate_callback = true }
    )
    M.controls.spark_size = register_flight_locked_control(spark_size_slider)
    place_grid_control(spark_size_slider, CONTROL_GRID.spark_size)
end

function M.BuildVigorTab(parent)
    local cfg = UI_CONFIG
    M.controls_parent = parent
    M.flight_locked_controls = {}
    M._settings_controls_flight_locked = nil
    M.settings_grid = addon.CreateSettingsGrid(parent, {
        column_count = 5,
        col_gap = cfg.slider_width + cfg.slider_gap_x,
        col_width = cfg.slider_width,
        col_offset = cfg.title_offset_x,
        row_start = cfg.title_offset_y,
        row_gap = cfg.grid_row_gap,
        row_heights = {
            cfg.slider_row_height,
            cfg.slider_row_height,
            cfg.slider_row_height,
            cfg.slider_row_height,
            cfg.slider_row_height,
        },
        col_align = { "left", "left", "left", "left", "left" },
        offsets = { default = 0 },
        separator_left = cfg.title_offset_x,
        separator_right_pad = 20,
        separator_stretch = true,
        row_separators = {
            ROWS.top,
            ROWS.position,
            ROWS.decor,
            ROWS.fade,
            ROWS.spark,
        },
    })
    local db = M.get_db()
    local root_db = M.get_root_db()
    local defaults = M.DEFAULTS
    local x_range = get_setting_range("x_position")
    local y_range = get_setting_range("y_position")
    local scale_range = get_setting_range("scale")
    local spacing_range = get_setting_range("spacing")
    local fill_add_range = get_setting_range("fill_add_alpha")
    local decor_scale_range = get_setting_range("decor_scale")
    local decor_x_range = get_setting_range("decor_x_position")
    local decor_y_range = get_setting_range("decor_y_position")
    local fade_alpha_range = get_setting_range("fade_alpha")
    local fade_length_range = get_setting_range("fade_length")
    local progress_update_hz_range = get_setting_range("progress_update_hz")
    local spark_size_range = get_setting_range("spark_size")
    local active_profile_proxy = setmetatable({}, {
        __index = function(_, key)
            local active_db = M.get_db()
            return active_db and active_db[key]
        end,
        __newindex = function(_, key, value)
            if M.is_settings_locked_by_flight() then
                M.sync_settings_controls(M.get_db())
                return
            end
            local active_db = M.get_db()
            if active_db then
                active_db[key] = value
            end
        end,
    })
    local position_proxy = setmetatable({}, {
        __index = function(_, key)
            local active_db = M.get_db()
            return active_db and active_db.position and active_db.position[key]
        end,
        __newindex = function(_, key, value)
            if M.is_settings_locked_by_flight() then
                M.sync_settings_controls(M.get_db())
                return
            end
            local active_db = M.get_db()
            if not active_db then return end
            active_db.position = active_db.position or {}
            active_db.position[key] = value
        end,
    })
    local context = {
        cfg = cfg,
        db = db,
        root_db = root_db,
        defaults = defaults,
        x_range = x_range,
        y_range = y_range,
        scale_range = scale_range,
        spacing_range = spacing_range,
        fill_add_range = fill_add_range,
        decor_scale_range = decor_scale_range,
        decor_x_range = decor_x_range,
        decor_y_range = decor_y_range,
        fade_alpha_range = fade_alpha_range,
        fade_length_range = fade_length_range,
        progress_update_hz_range = progress_update_hz_range,
        spark_size_range = spark_size_range,
        active_profile_proxy = active_profile_proxy,
        position_proxy = position_proxy,
    }

    build_top_row(parent, context)

    build_position_row(parent, context)

    build_decor_row(parent, context)

    build_fade_row(parent, context)

    build_race_profile_panel(parent, context)

    build_spark_row(parent, context)

    M.sync_settings_controls_enabled(true)
end

--#endregion SETTINGS CONSTRUCTION =============================================
