-- Default DB values for the Skyriding Vigor module.
-- Consumed by addon.apply_defaults() on first load and after reset.


--#region FILE CONTENTS ======================================================

local _, addon = ...

addon.skyriding_vigor = {
    controls = {},
    flight_locked_controls = {},
    slots = {},
}

local default_progress_interval = addon.UPDATE_INTERVALS.skyriding_vigor_progress

local function build_profile_defaults()
    return {
        enabled = true,
        fade_when_full = true,
        fade_alpha = addon.DEFAULT_FADE_ALPHA,
        fade_length = 3,
        show_spark = false,
        spark_color = { r = 1, g = 1, b = 1, a = 1 },
        spark_size = 5.00,
        move_mode = false,
        snap_to_grid = true,
        style = "default",
        decor_style = "default",
        spacing = 5,
        scale = 1.0,
        progress_update_hz = 1 / default_progress_interval,
        style_layouts = {
            default = {
                fill_color = { r = 0.00, g = 0.80, b = 1.00, a = 1 },
                fill_add_alpha = 0.5,
            },
            storm_race = {
                fill_color = { r = 1, g = 1, b = 1, a = 1 },
                fill_add_alpha = 0.5,
            },
        },
        position = {
            point = "CENTER",
            relativePoint = "CENTER",
            x = 0,
            y = 0,
        },
    }
end

local defs = {}
local normal_profile = build_profile_defaults()
normal_profile.race_profile_enabled = false
normal_profile.race_profile = build_profile_defaults()
normal_profile.profiles = {}
normal_profile.last_profile_name = nil
normal_profile.last_tab_index = 1

defs.defaults = {
    skyriding_vigor = normal_profile,
}

addon.module_defaults.sv = defs.defaults

return defs

--#endregion FILE CONTENTS ===================================================
