# L's Tweeks
L's Tweeks is a modular World of Warcraft Retail UI addon for configurable player aura frames, player frame adjustments, small interface adjustments, and quieter replacement sounds.

Slash command: `/lst`

Release history: [Changelog](CHANGELOG.md)


## Table of Contents
- [Modules](#modules)
  - [Aura Frames](#aura-frames)
  - [Player Frame](#player-frame)
  - [Objectives](#objectives)
  - [Skyriding Vigor](#skyriding-vigor)
  - [Audio Volumes](#audio-volumes)
  - [Settings](#settings)
- [Installation](#installation)
- [Use Notes](#use-notes)
- [Embedded Libraries](#embedded-libraries)
- [License](#license)
- [Credits](#credits)
- [Sources](#sources)


## Modules
- [Aura Frames](#aura-frames): configurable player aura frames for buffs, debuffs, and WoW Cooldown Manager groups.
- [Player Frame](#player-frame): optional Player Frame combat-text hiding and out-of-combat fade controls.
- [Objectives](#objectives): position, background, auto-collapse, and section-count controls for the Objective Tracker.
- [Skyriding Vigor](#skyriding-vigor): restored compact player vigor display with adjustable style and behavior.
- [Audio Volumes](#audio-volumes): quieter replacement sounds and temporary channel-volume situations.
- [Settings](#settings): minimap button, open-on-reload, and main panel transparency.
- [ChatCopySghetti](#chatcopysghetti): selected chat history export for manual copying.


### ChatCopySghetti
- Click the two-page copy icon just outside a regular chat window's top-left corner to open its copy popup.
- Select text in the export window and press **Ctrl+C**. **Select All** selects the full export; **Escape** or the top-right **X** dismisses it and clears the text.
- Drag the popup to move it and drag its bottom-right grip to resize it. Size and position are remembered across reloads; module reset restores the default centered layout.
- Use the top-left gear to open this module's settings. Configure Recent Lines, Keep Link Brackets, and Popup BG color/transparency. Copy icons follow module enablement. The copy window preserves chat colors and intentional line breaks while removing inline artwork; Ctrl+C copies the selected text.
- The button beside the X minimizes the popup to its title bar and restores it without losing the displayed text. New exports reopen the expanded window.
- Exports retained readable chat lines. All skipped lines are counted together, including lines excluded by the recent-line or output-size limit. A line means one stored chat entry, regardless of visual wrapping. The combat log, combat-time export, and chat messaging lockdown are excluded. Chat history is not saved.


### Aura Frames
Aura Frames replace and extend the default player buff and debuff display. The module includes preset player-aura frames, WoW Cooldown Manager-backed frames, and custom filtered frames.

The Aura Frames **Shared Options** tab provides shared **BG Colors**, **Bar Colors**, and compact **Text Options** launchers, with one participation checkbox per group for every built-in and custom frame. Shared Bar, Timer, and Stack Text Options contain Color, Font, Font Size, Bold, and Outline; edits preview immediately on participating frames, Save retains them, Cancel restores the opening values, and Reset previews the defaults. The shared settings are disabled by default and included in Aura Frames profiles and resets. **Enable Test Auras**/Play/Pause and **Disable OOC Fade** are Aura-owned shared controls that remain available when shared styling is disabled; individual Test Aura controls remain available on every Aura frame tab.


#### Preset Frames
- `Short Buffs`: helpful player auras whose total duration is at or below its configured maximum; the default is five minutes, and the next expiration is shown first.
- `Static / Long Buffs`: helpful player auras last observed outside combat with no duration or a total duration above the Short Buffs maximum. Learned spell IDs persist across reloads and can be cleared from this frame's settings.
- `Timed Buffs`: helpful player auras with an expiration time through WoW's managed Aura display.
- `Debuffs`: harmful player auras through WoW's managed Aura display.

After WoW 12.1, all four preset frames use combat-safe managed Aura paths. Short Buffs and Timed Buffs delegate duration filtering to WoW. Static / Long Buffs learns readable helpful-Aura durations only outside combat, then gives WoW the learned spell-ID inclusion set; unknown buffs remain hidden until observed outside combat. Short Buffs does not receive longer buffs when their remaining time crosses its maximum because classification uses total duration.

Aura Frames use a fixed internal safety limit of 40 entries. Blizzard or the owning frame implementation selects and arranges the displayed auras; there is no adjustable pool-size setting.

When Frame BG is enabled for managed Short Buffs, Static / Long Buffs, Timed Buffs, or Debuffs, an empty frame retains one configured-width row so its future placement remains visible; the background expands as native Aura rows appear.

Each Aura frame has compact Bar, Timer, and Stack Text Options launchers. Their shared popup provides Color, Font, Font Size, Bold, Outline, Save, Cancel, and Reset while keeping the main frame panel uncluttered.

In Icon mode, **Duration Swipe** adds Blizzard's native Aura-duration sweep alongside the optional timer text. Permanent Auras have no timed sweep. Bar Mode communicates remaining duration through its status bar instead.

#### Test Aura Preview
Use **Test Aura** to preview any Aura frame. Its adjacent Play/Pause button controls the preview countdown; a saved active preview loads paused after reload until you select Play. Short Buffs, Static / Long Buffs, Timed Buffs, and Debuffs keep their native managed content visible while displaying one addon-owned mock on the side opposite their growth direction. If that preview would cross a screen edge, the frame shifts inward temporarily without changing its saved position. Cooldown Manager Aura-mode frames use the same separate preview placement; Essential and Utility Cooldown Mode place the mock in their normal addon-rendered sequence. Tracked Buffs and Tracked Bars intentionally remain Aura-mode-only.


#### Tooltips
Managed Short Buffs, Static / Long Buffs, Timed Buffs, Debuffs, and active Cooldown Manager Auras use Blizzard's native detailed Aura tooltips both in and out of combat. The Short Buffs mover tooltip reports its configured maximum duration; the Static / Long Buffs mover tooltip reports the learned inclusion count and current Short maximum. Custom frames and addon-rendered CDM cooldown entries use LsTweeks' guarded tooltip cache: information seen before combat is remembered until logout or reload, while restricted effects first encountered in combat may show only readable fallback details.

#### Aura Cancellation
Right-click a supported cancelable player buff to remove it. Static / Long Buffs uses Blizzard's native AuraButton cancellation and inherits Blizzard's restrictions; custom frames use the addon-owned out-of-combat cancellation path. Short Buffs, Timed Buffs, Debuffs, and Cooldown Manager entries are not cancelable through LsTweeks.


#### WoW Cooldown Manager Frames
Cooldown Manager-backed frames combine Blizzard managed Auras with live Cooldown Manager cooldown state:

- `Essential`
- `Utility`
- `Tracked Buffs`
- `Tracked Bars`

Active Auras are displayed through WoW 12.1 managed Aura groups and slots, so LsTweeks does not read their protected Aura data. Aura mode uses compact native groups in Cooldown Manager order. Cooldown mode keeps an addon-rendered cooldown cell underneath each stable native Aura slot; when an active Aura ends, Blizzard hides the slot and reveals the continuing cooldown.

Cooldown mode reads effective saved category/order from Blizzard's Cooldown Manager data provider, spell metadata through the public `C_CooldownViewer` API, and cooldown/charge timing through `C_Spell` duration objects; it does not inspect or hook Blizzard Cooldown Viewer frames. The matching **Hide WoW ...** option is therefore independent of cooldown transport and only suppresses the native viewer visually. Saving category or order edits in WoW's Cooldown Manager refreshes the addon frames automatically; **Sync to CDM** remains available as a manual fallback.


#### Custom Filtered Frames
Custom frames scan player auras directly with a selected AuraFilters string. Example:

```lua
C_UnitAuras.GetAuraDataByIndex("player", i, "HELPFUL|IMPORTANT")
```

The `IMPORTANT` AuraFilter was added in WoW 12.0.1 and is described as spells that pass `C_Spell.IsSpellImportant()`.


#### Profiles
Profiles save the full Aura Frames setup, including preset frame settings, Cooldown Manager-backed frame presentation, positions, colors, timer styling, and custom filtered frames. Loading a profile replaces the current Aura Frames setup and recreates missing custom frames. Profile loading is blocked during combat.

Aura Frames, Audio Volumes, Objectives, and Skyriding Vigor reset panels include a checked **Keep Profiles** option so saved profiles can survive a module reset.


### Player Frame
Player Frame adjustments are small, independent tweaks to the default Blizzard Player Frame; there is no dedicated presentation module beyond the toggles below.

- **Hide Portrait Combat Text**: hides the floating combat text that appears over the Player Frame portrait.
- **Out-of-Combat Fade**: fades the Player Frame when out of combat, restoring full opacity on combat start.


### Objectives
Objectives extends and restyles the Blizzard Objective Tracker (All Objectives, Campaign, Quests, Achievements) without replacing its underlying frames.

- **Position**: separate controls for moving the All Objectives tracker, including snap-to-grid offsets.
- **Background**: separate controls for Blizzard's Objective Tracker background and LsTweeks' custom color background, sized to the visible tracker sections when Objectives module behavior is active.
- **Auto-Collapse**: optionally hides Campaign, Quests, and Achievements contents without changing Blizzard's native collapsed state. After login or reload, the checked-by-default **Activation Reminder** shows a session help tooltip instructing you to click every enabled section button twice to activate Auto-Hide; uncheck it to suppress the reminder. A manual expansion stays open until that section is manually collapsed again. This taint-safe fallback can retain empty layout space because Blizzard still budgets the expanded section height; the parent All Objectives tracker remains Blizzard-owned.
- **Section Count**: optional checkboxes for quest log and tracked achievement counters, with per-counter **On Hover** display options.
- **Profiles**: saving and loading complete Objective Tracker setups, plus a module reset that can preserve saved profiles.


### Skyriding Vigor
Skyriding Vigor restores a compact player vigor display using Blizzard UI assets, replacing the space left by the removed default vigor bar.

- Adjustable position, size, and spacing.
- Adjustable node style/color, fill color, and end-decoration style/color.
- Adjustable fade behavior.
- Optional separate profile per race.
- **Profiles**: saving and loading complete Vigor Bar setups, plus a module reset that can preserve saved profiles.


### Audio Volumes
WoW does not expose true per-sound volume control or custom sound channels. This addon mutes known original Blizzard FileDataIDs where configured, then optionally plays addon-owned replacement files at the selected level.

Current sound targets:

- `Achievement`: local test target for slider and preview behavior.
- `Ready Check`: replacement control for ready check and LFG proposal sounds.

Replacement volume is shown as `0-100%` in 5% steps. `0%` is off. The **Original** checkbox keeps Blizzard's original sound and dims the replacement slider until the slider is moved.

The **Situations** tab always shows Normal Volumes for the user's regular Master, Music, Effects, Ambience, and Dialog channel volumes. Its list has a Triggered group for Fishing and Combat plus a Quick Picks group for Quiet Custom and user-created custom Quick Picks. Fishing and Combat have title-bar enable checkboxes for automatic activation. Combat starts use `PLAYER_REGEN_DISABLED`, combat ends use `PLAYER_REGEN_ENABLED`, and entering combat exits the Fishing situation.

Quick Picks store manual sound-channel situations and do not auto-trigger because there is no user-facing trigger builder. Right-clicking the minimap button includes **Normal Volumes** to clear the active Quick Pick. Fishing and Combat temporarily override an enabled Quick Pick, then the Quick Pick resumes afterward. The Play buttons preview the selected situation with the Fishing Bobber splash sound. Exact Fishing Bobber bite-sound replacement is not available because the bite timing is not exposed through the tested Lua hooks/APIs.

Sound target details are tracked in `modules/audio_volumes/sounds/sound_reference.md`.


### Settings
Settings covers addon-wide behavior rather than a specific module's presentation.

- **Minimap Button**: optional minimap button, with a right-click menu for module-specific quick actions such as Audio Volumes' Normal Volumes.
- **Open On Reload**: optionally opens the settings panel automatically after a `/reload`.
- **Panel Transparency**: main settings panel transparency control.


## Installation
1. Download or clone the addon.
2. Ensure the addon folder is named `LsTweeks`.
3. Place the folder here:

```text
World of Warcraft/_retail_/Interface/AddOns/LsTweeks
```

4. Launch or reload the game.
5. Enable **L's Tweeks** in the AddOns menu.

For CurseForge/manual zip installs, the archive should extract to a single top-level `LsTweeks` folder.


## Use Notes
- Open the settings panel with `/lst` or the minimap button.
- Use `/lst status` for all module diagnostics, or `/lst status <module>` for one module such as `/lst status objectives`.
- Open **Buffs & Debuffs** for aura frame settings.
- Use **Buffs & Debuffs > Profiles** to save or load complete Aura Frames setups.
- Open **Settings** for minimap, open-on-reload, interface transparency, and module enable toggles.
- Open **Objectives** for Tracker settings, module reset, and saved profiles.
- Open **Skyriding Vigor** for General module controls, Vigor Bar appearance and behavior, and saved profiles.
- Open **Audio Volumes** to configure replacement sounds and temporary-volume situations, reset the module, or manage saved profiles.


## Embedded Libraries
Embedded libraries are stored in `libs/` and credited in `sources.md`. They are vendored third-party files and are kept unmodified.

- CallbackHandler-1.0
- LibDBIcon-1.0
- LibDataBroker-1.1
- LibStub


## License
- This project is released under the MIT License.
- Embedded libraries retain their original licenses as listed in `sources.md`.
- See `LICENSE` for full details.
- Copyright (c) 2026 **LockBall**.


## Credits
#### Libraries
- LibStub, CallbackHandler-1.0, LibDataBroker-1.1, and LibDBIcon-1.0 by their respective authors on WowAce / CurseForge

#### Inspiration
For non-lib inspirational sources, this addon uses its own implementation, Blizzard UI assets and public API
The WoW addon community:
- Elkano's BuffBars
- BetterCooldownManager
- TellMeWhen, ArcUI, EllesmereUI: confirm community-tested WoW 12.1 managed AuraContainer/AuraButton direction
- BasicBuffHide: hidden-parent suppression for Blizzard's 12.1 BuffFrame (no longer used)
- Angleur: fishing audio profiles
- Quest Log Collapse: research lead for the rejected securecall Objective Tracker experiment
- DragonRider: restored vigor-display
- Chat Copy Paste: chat-copy interaction and formatting inspiration; independently implemented as ChatCopySghetti

#### Hoomans
- Design and implementation by **LockBall**
- Special thanks to **DiscoMouse**

#### Non-Hoomans
- Portions of this addon were developed with agentic tools assistance


## Sources
Public credits and embedded library sources are tracked in `sources.md`.
